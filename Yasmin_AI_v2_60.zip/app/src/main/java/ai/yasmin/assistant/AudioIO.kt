package ai.yasmin.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.SystemClock
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Mic capture (16 kHz PCM) + speaker playback (24 kHz PCM), tuned for low latency and echo cancellation. */
class AudioIO(private val ctx: Context, private val onMic: (ByteArray) -> Unit) {
    @Volatile private var run = false
    private var rec: AudioRecord? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var fastTrack = false   // track was built on the low-latency path
    private var am: AudioManager? = null
    // Each chunk is tagged with the "epoch" it belongs to, so speech that was interrupted can never leak out after a flush.
    private val q = LinkedBlockingQueue<Pair<Int, ByteArray>>()
    private val epoch = AtomicInteger(0)
    @Volatile private var written = 0L   // 16-bit samples handed to the speaker so far (lets us know if sound is still coming out)

    @Volatile private var held = 0   // bytes waiting in the jitter buffer

    // v2.42: the audio effects MUST be kept in fields. They used to be created and dropped: the garbage collector then released the
    // echo canceller after a few minutes and Yasmin started to hear (and answer) her own voice.
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null

    // v2.42: echo gate state (see gate()).
    @Volatile private var lastPlayingAt = 0L
    private var gateOpenUntil = 0L
    private var echoFloor = 0.02f
    private var loudRun = 0
    @Volatile private var headsetOut = false
    @Volatile private var preRoll = PRE_ROLL_MIN   // adaptive jitter buffer: grows after an underrun, shrinks again on a calm connection

    companion object {
        private const val PRE_ROLL_MIN = 9600    // 200 ms of 24 kHz 16-bit mono
        private const val PRE_ROLL_MAX = 33600   // 700 ms: for a bad connection
        private const val MIC_CHUNK = 1280       // 40 ms of 16 kHz 16-bit mono (half the network messages of 20 ms, still low latency)
        @Volatile private var current: AudioIO? = null
        /** Called by the pitch slider: re-applies the saved pitch to the running speaker. */
        fun pitchChanged() { current?.let { it.applyPitch(it.track) } }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        am = ctx.getSystemService(AudioManager::class.java)
        am?.mode = AudioManager.MODE_IN_COMMUNICATION
        route()
        val minIn = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minIn, 3200) * 2
        )
        if (r.state != AudioRecord.STATE_INITIALIZED) { try { r.release() } catch (_: Exception) {}; throw IllegalStateException("microphone could not be opened (another app may be using it)") }
        try { if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.setEnabled(true) } } catch (_: Exception) {}
        try { if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.setEnabled(true) } } catch (_: Exception) {}
        // v2.14: automatic gain keeps a quiet or far voice at a level the speech recogniser understands
        try { if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(r.audioSessionId)?.also { it.setEnabled(true) } } catch (_: Exception) {}
        rec = r

        val t = buildTrack()
        track = t
        current = this
        applyPitch(t)
        run = true
        r.startRecording()
        t.play()

        thread(name = "yasmin-mic", isDaemon = true) {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (_: Exception) {}
            val buf = ByteArray(MIC_CHUNK)
            var filled = 0
            while (run) {
                val n = r.read(buf, filled, buf.size - filled)
                if (n > 0) {
                    filled += n
                    if (filled < buf.size) continue   // always hand over full 40 ms blocks
                    filled = 0
                    AppState.level.value = rms(buf, buf.size)
                    onMic(gate(buf.copyOf(), buf.size))
                } else if (n < 0) break
            }
        }
        thread(name = "yasmin-speaker", isDaemon = true) {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (_: Exception) {}
            var carry = -1 // leftover odd byte: keeps 16-bit samples aligned across network chunks
            var seen = epoch.get()
            // Jitter buffer: Gemini audio arrives in bursts over the mobile network. If the speaker buffer runs dry in the middle of a
            // word (underrun) many phones play crackle / radio-style static. So every answer first collects "preRoll" of audio and only
            // then starts; a chunk that stops arriving flushes what was collected after 60 ms.
            val pre = ArrayList<ByteArray>()
            var preBytes = 0
            var primed = false
            var lastUnderrun = 0
            var noiseMuted = 0
            var turnUnderruns = 0

            fun emit(b: ByteArray, e: Int) {
                val lv = rms(b, b.size)
                AppState.level.value = lv
                AppState.outLevel.value = lv
                AppState.outAt = android.os.SystemClock.uptimeMillis()
                var off = 0
                while (off < b.size && run && e == epoch.get()) {
                    val w = track?.write(b, off, b.size - off) ?: break
                    if (w < 0) { recoverTrack(w); break }
                    off += w
                    written += w / 2
                }
                if (Build.VERSION.SDK_INT >= 24) try {
                    val u = track?.underrunCount ?: 0
                    if (u > lastUnderrun) {
                        // The network was too slow for a moment: collect more audio before the next start so the voice does not stutter again.
                        lastUnderrun = u; turnUnderruns++
                        preRoll = min(PRE_ROLL_MAX, preRoll + 4800)
                    }
                } catch (_: Exception) {}
            }
            fun rebase() { try { lastUnderrun = track?.underrunCount ?: lastUnderrun } catch (_: Exception) {} }   // the speaker running empty between two answers is normal, not a stutter
            fun release(e: Int) {
                val items = ArrayList(pre); pre.clear(); preBytes = 0; held = 0; primed = true
                rebase()
                for (c in items) emit(c, e)
            }

            while (run) {
                val item = q.poll(if (!primed && preBytes > 0) 250L else 150L, TimeUnit.MILLISECONDS)
                if (item == null) {
                    if (!primed && preBytes > 0) release(epoch.get())
                    // Nothing arrived and the speaker has almost played everything it had: the next burst is collected first,
                    // so a word never starts with half a buffer (that was the "stop-go" sound).
                    else if (primed && written - head() < 600) { primed = false; turnUnderruns++; preRoll = min(PRE_ROLL_MAX, preRoll + 2400) }
                    continue
                }
                val (e, raw) = item
                val cur = epoch.get()
                // After an interruption the queue is emptied, so a carried odd byte of the OLD speech must be dropped too,
                // otherwise the next answer starts one byte off and every sample is garbled (sounds like another voice).
                if (cur != seen) { seen = cur; carry = -1; pre.clear(); preBytes = 0; held = 0; primed = false }
                if (e != cur) { carry = -1; continue } // belonged to interrupted speech
                if (raw.isEmpty()) {   // end-of-turn marker: start the next answer sample-aligned
                    if (!primed && preBytes > 0) release(e)
                    carry = -1; primed = false
                    if (turnUnderruns == 0) preRoll = max(PRE_ROLL_MIN, preRoll - 2400) else turnUnderruns = 0   // calm connection: shrink again
                    rebase()
                    emit(ByteArray(960), e)   // 20 ms of silence so the end of the buffer is never a loud sample that can repeat
                    continue
                }
                var b = raw
                if (carry >= 0) {
                    val m = ByteArray(b.size + 1)
                    m[0] = carry.toByte()
                    System.arraycopy(b, 0, m, 1, b.size)
                    b = m; carry = -1
                }
                if (b.size % 2 == 1) { carry = b[b.size - 1].toInt() and 0xFF; b = b.copyOf(b.size - 1) }
                if (b.isEmpty()) continue
                if (isNoiseBurst(b)) {   // a glitch of the model (seen with Gemini 3.1): loud broadband hiss instead of a voice
                    b = ByteArray(b.size)
                    if (++noiseMuted % 5 == 1) AppState.add("Audio: a loud noise burst from the voice model was muted (#$noiseMuted)")
                }
                if (primed) emit(b, e)
                else {
                    pre.add(b); preBytes += b.size; held = preBytes
                    if (preBytes >= preRoll) release(e)
                }
            }
        }
    }

    /** Output device died or stopped (route change, Bluetooth switch): rebuild instead of going silent or garbled. */
    private fun recoverTrack(err: Int) {
        try {
            if (err == AudioTrack.ERROR_DEAD_OBJECT) {
                try { track?.release() } catch (_: Exception) {}
                val nt = buildTrack(); track = nt; applyPitch(nt); nt.play(); written = 0L
            } else track?.play()
        } catch (_: Exception) {}
    }

    private fun buildTrack(): AudioTrack {
        val minOut = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        fastTrack = false
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setSampleRate(24000)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(minOut * 4, 38400))   // ~800 ms capacity: absorbs network jitter (an underrun can sound like buzzing); adds no delay
            .setTransferMode(AudioTrack.MODE_STREAM)
            // v2.17: the low-latency "fast" path cannot change pitch, so it is used only while the pitch is normal
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_NONE)   // the low-latency fast path underruns easily and crackles on many phones; speech from the network does not need it
            .build()
    }

    /**
     * Pitch slider. First choice: change the pitch alone (speed stays the same). If this phone refuses that,
     * the playback rate is changed instead, which moves pitch and speed together (small slider steps still sound natural).
     */
    private fun applyPitch(t: AudioTrack?) {
        val tr = t ?: return
        val pct = VoicePitch.saved(ctx)
        val p = pct / 100f
        // Normal pitch on the low-latency path: leave the track alone. Forcing time-stretch parameters onto the fast mixer
        // makes some phones produce crackle / static.
        if (fastTrack && pct == VoicePitch.DEFAULT) return
        try {
            tr.playbackParams = PlaybackParams().setPitch(p).setSpeed(1f)
        } catch (_: Exception) {
            try { tr.playbackRate = (24000 * p).toInt() } catch (_: Exception) {}
        }
    }

    fun play(pcm: ByteArray) { q.offer(epoch.get() to pcm) }

    /** Marks the end of one answer so the next one always starts on a clean 16-bit sample boundary. */
    fun endTurn() { q.offer(epoch.get() to ByteArray(0)) }

    /** Called when the user interrupts (barge-in): drop queued speech instantly. */
    fun flush() {
        q.clear()
        epoch.incrementAndGet()
        try { track?.pause(); track?.flush(); track?.play() } catch (_: Exception) {}
        written = head()
    }

    private fun head(): Long = try { (track?.playbackHeadPosition ?: 0).toLong() and 0xFFFFFFFFL } catch (_: Exception) { 0L }

    /** True while queued or buffered speech is still coming out of the speaker (the voice check must not score Yasmin's own voice). */
    fun isPlaying(): Boolean = !q.isEmpty() || held > 0 || written - head() > 240

    fun stop() {
        run = false
        if (current === this) current = null
        try { rec?.stop() } catch (_: Exception) {}
        try { aec?.release() } catch (_: Exception) {}
        try { ns?.release() } catch (_: Exception) {}
        try { agc?.release() } catch (_: Exception) {}
        aec = null; ns = null; agc = null
        try { rec?.release() } catch (_: Exception) {}
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        rec = null; track = null
        val a = am ?: return
        a.mode = AudioManager.MODE_NORMAL
        if (Build.VERSION.SDK_INT >= 31) a.clearCommunicationDevice() else a.isSpeakerphoneOn = false
    }

    private fun route() {
        val a = am ?: return
        headsetOut = headsetPlugged(a)
        if (Build.VERSION.SDK_INT >= 31) {
            val devs = a.availableCommunicationDevices
            val headset = intArrayOf(
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_USB_HEADSET
            )
            val pick = devs.firstOrNull { it.type in headset }
                ?: devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            if (pick != null) a.setCommunicationDevice(pick)
        } else {
            @Suppress("DEPRECATION")
            a.isSpeakerphoneOn = true
        }
    }

    private fun headsetPlugged(a: AudioManager): Boolean = try {
        a.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            it.type == AudioDeviceInfo.TYPE_USB_HEADSET || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || (Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
    } catch (_: Exception) { false }

    /**
     * v2.42 echo gate. On the loudspeaker even a good echo canceller leaks a little of Yasmin's voice into the microphone; Gemini then
     * "hears" itself, answers itself or cuts itself off. While Yasmin is speaking (and for 350 ms after) the microphone sends silence,
     * unless the user clearly talks over her: the mic must be well above the echo level we measured for 3 blocks in a row (120 ms).
     * With a headset the gate is off, because there is no echo.
     */
    private fun gate(b: ByteArray, n: Int): ByteArray {
        if (headsetOut) return b
        val now = SystemClock.uptimeMillis()
        if (isPlaying()) lastPlayingAt = now
        // v2.53: the tail of her voice in the room lasts longer than 350 ms, so the gate stays shut for 500 ms after she stops.
        if (now - lastPlayingAt > 500) { loudRun = 0; echoFloor = max(0.02f, echoFloor * 0.9f); return b }
        if (now < gateOpenUntil) return b                       // the user is talking over her: let it through
        var s = 0.0
        var i = 0
        while (i + 1 < n) { val v = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt() / 32768.0; s += v * v; i += 2 }
        val r = sqrt(s / max(1, n / 2)).toFloat()
        // v2.53: the echo grows with what she is playing right now (AppState.outLevel), so the bar follows her volume.
        // Before, a loud passage pushed the echo over a fixed bar, the gate opened for 800 ms and she heard herself.
        val echoNow = max(echoFloor, AppState.outLevel.value * 0.2f)   // outLevel comes from rms(), which is 4x the scale used here
        val threshold = max(0.12f, echoNow * 3f)
        if (r > threshold) loudRun++ else { loudRun = 0; echoFloor = min(0.25f, max(r, echoFloor * 0.995f)) }
        // A real interruption is loud and lasts: 5 blocks (200 ms) in a row, and the gate stays open only 500 ms.
        if (loudRun >= 5) { gateOpenUntil = now + 500; loudRun = 0; return b }
        return ByteArray(n)                                      // silence of the same length: the stream stays continuous
    }

    /**
     * Speech is smooth (neighbouring samples are alike); a hiss is not. Compare the energy of the sample-to-sample difference with the
     * energy of the signal: white noise gives about 2.0, speech stays well below 1 (even "s" sounds are quiet). Only a chunk of at least
     * 10 ms that is both LOUD and noise-like counts, so normal speech is never touched.
     */
    private fun isNoiseBurst(b: ByteArray): Boolean {
        val n = b.size / 2
        if (n < 240) return false
        var e = 0.0; var d = 0.0; var prev = 0.0
        for (k in 0 until n) {
            val v = (((b[2 * k + 1].toInt() shl 8) or (b[2 * k].toInt() and 0xFF)).toShort().toInt()) / 32768.0
            e += v * v
            if (k > 0) { val x = v - prev; d += x * x }
            prev = v
        }
        val rms = sqrt(e / n)
        return rms > 0.12 && d / (e + 1e-9) > 1.4
    }

    private fun rms(b: ByteArray, n: Int): Float {
        var s = 0.0
        var i = 0
        val cnt = n / 2
        if (cnt == 0) return 0f
        while (i + 1 < n) {
            val v = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt() / 32768.0
            s += v * v
            i += 2
        }
        return min(1f, (sqrt(s / cnt) * 4).toFloat())
    }
}
