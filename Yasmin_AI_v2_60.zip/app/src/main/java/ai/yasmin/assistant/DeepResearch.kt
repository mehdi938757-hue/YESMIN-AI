package ai.yasmin.assistant

import android.content.Context
import android.os.Environment
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** v2.57: deep research. Gemini searches the web (Google Search grounding), the result is saved as a Markdown document. */
object DeepResearch {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    private const val RULES = "You are a careful research writer. Search the web for current, reliable information. " +
        "Write a clear, well organized Markdown document: a title, short sections with headings, key facts with dates and numbers, " +
        "and a short conclusion. Never invent facts. Say clearly when something is uncertain or conflicting. " +
        "Write in the same language as the request (Hindi, Hinglish or English)."

    /** Documents/Yasmin on shared storage when allowed, otherwise the app's private files folder. */
    fun folder(ctx: Context): File {
        val pub = try {
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "Yasmin")
        } catch (_: Exception) { null }
        return pub?.takeIf { (it.exists() || it.mkdirs()) && it.canWrite() }
            ?: File(ctx.filesDir, "documents").apply { mkdirs() }
    }

    fun list(ctx: Context): List<File> =
        folder(ctx).listFiles()?.filter { it.isFile && it.name.endsWith(".md") }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun run(ctx: Context, topic: String): JSONObject {
        if (topic.isBlank()) return JSONObject().put("ok", false).put("error", "No topic was given. Ask what to research.")
        val key = Prefs.get(ctx, Prefs.KEY, "")
        if (key.isBlank()) return JSONObject().put("ok", false).put("error", "No Gemini API key is set. Add it in API Key settings.")
        return try {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", RULES))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", "Research and write the document about: $topic")))))
                .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
                .put("generationConfig", JSONObject().put("temperature", 0.3).put("maxOutputTokens", 8000))
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/${VisionModels.FALLBACK}:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { resp ->
                val txt = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return JSONObject().put("ok", false).put("error", "Research model HTTP ${resp.code}: ${txt.take(200)}")
                val cand = JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)
                    ?: return JSONObject().put("ok", false).put("error", "The research model returned nothing.")
                val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
                val text = sb.toString().trim()
                if (text.isEmpty()) return JSONObject().put("ok", false).put("error", "The research came back empty. Try a more specific topic.")

                val sources = LinkedHashMap<String, String>()
                cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")?.let { arr ->
                    for (i in 0 until arr.length()) {
                        val w = arr.optJSONObject(i)?.optJSONObject("web") ?: continue
                        val uri = w.optString("uri")
                        if (uri.isNotBlank()) sources[uri] = w.optString("title", uri)
                    }
                }
                val doc = StringBuilder("# $topic\n\n").append(text).append("\n")
                if (sources.isNotEmpty()) {
                    doc.append("\n## Sources\n")
                    sources.forEach { (u, t) -> doc.append("- [$t]($u)\n") }
                }
                val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                val slug = topic.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "-").trim('-').take(40).ifEmpty { "research" }
                val file = File(folder(ctx), "${slug}_$stamp.md")
                file.writeText(doc.toString())
                JSONObject().put("ok", true).put("saved_to", file.absolutePath).put("title", topic)
                    .put("summary", text.take(500))
                    .put("note", "The full document is saved in Documents. Tell him the short summary in a few sentences, do not read the whole document.")
            }
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", "Research failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }
}
