package ai.yasmin.assistant

import android.graphics.BitmapFactory
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp as colorLerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * v2.31, 2D anime character ("Live2D style") for the home page.
 *
 * The artwork (yasmin_character.webp, 768 x 1376) is one flat picture. To make it move like a 2D anime / VTuber model
 * without needing a Live2D runtime, the picture is drawn as a deformable mesh (Canvas.drawBitmapMesh) and every
 * frame the mesh vertices are pushed around by small, smooth "deformers", exactly the idea Live2D uses:
 *
 *   - body sway   : the whole upper body rocks gently around the hips
 *   - breathing   : chest rises and widens, head lifts a little
 *   - hair sway   : both long side tails swing like they are caught in a breeze (more at the tips)
 *   - arms        : (v2.34) both arms hang down, the waving hand is gone
 *   - emotions    : (v2.34) the face follows the AI's mood (set_emotion): eyebrows, eyelids, mouth, blush, hearts, tears, anger mark ...
 *   - ears        : the cat ears twitch (left and right at different times)
 *   - ahoge       : the little hair antenna wobbles
 *   - blinking    : eyelids close and open (two independent timers, so it never looks mechanical)
 *   - talking     : when the assistant speaks the mouth opens and closes with her voice (lip-sync) and the head nods
 *   - cherry petals and twinkling sparkles float over the scene
 *
 * Everything is cheap (about 1,900 vertices per frame), no extra libraries, no extra assets.
 */

// v2.37: the background around the character slowly drifts through soft colours (pink > lavender > sky > mint > peach > rose)
private val TINTS = arrayOf(Color(0xFFFF9EC8), Color(0xFFB69CFF), Color(0xFF7FD8FF), Color(0xFF8CF0C8), Color(0xFFFFC98A), Color(0xFFFF8FA3))
private const val TINT_HOLD = 8f      // seconds per colour, the change itself takes about 5 of them

private fun tintAt(time: Float): Color {
    val u = time / TINT_HOLD
    val i = u.toInt()
    val a = TINTS[i % TINTS.size]
    val b = TINTS[(i + 1) % TINTS.size]
    return colorLerp(a, b, sm(0.35f, 1f, u - i))
}

private const val COLS = 32
private const val TAU = 6.2831855f
private const val PI_F = 3.1415927f

// v2.43: eyelid skin tones and lash colour now come from the CharProfile (Characters.kt), one set per artwork

private fun sm(e0: Float, e1: Float, x: Float): Float {
    val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

private fun bell(v: Float, c: Float, w: Float): Float {
    val d = (v - c) / w
    return exp(-d * d)
}

/** 1 inside the ellipse, smoothly 0 outside. */
private fun ell(x: Float, y: Float, cx: Float, cy: Float, rx: Float, ry: Float): Float {
    val a = (x - cx) / rx
    val b = (y - cy) / ry
    return 1f - sm(0.8f, 1.3f, sqrt(a * a + b * b))
}

/** v2.34: how much of the 24 px square around every mesh vertex is pink hair (0..1), smoothed, so hair can swing on its own. */
private fun hairWeights(bmp: android.graphics.Bitmap, rows: Int): FloatArray {
    val w = bmp.width
    val h = bmp.height
    val px = IntArray(w * h)
    bmp.getPixels(px, 0, w, 0, 0, w, h)
    val g = FloatArray((COLS + 1) * (rows + 1))
    for (r in 0..rows) {
        for (c in 0..COLS) {
            val cx = (w * c / COLS).coerceIn(0, w - 1)
            val cy = (h * r / rows).coerceIn(0, h - 1)
            var n = 0
            var tot = 0
            var dy = -18
            while (dy <= 18) {
                var dx = -18
                while (dx <= 18) {
                    val xx = (cx + dx).coerceIn(0, w - 1)
                    val yy = (cy + dy).coerceIn(0, h - 1)
                    val p = px[yy * w + xx]
                    val rr = (p shr 16) and 255
                    val gg = (p shr 8) and 255
                    val bb = p and 255
                    tot++
                    if (rr > 190 && bb > gg + 6 && bb < rr - 10 && gg < 208) n++
                    dx += 6
                }
                dy += 6
            }
            g[r * (COLS + 1) + c] = n.toFloat() / tot
        }
    }
    // soften with a 3 x 3 average so the swing fades out smoothly at the edge of the hair
    val o = FloatArray(g.size)
    for (r in 0..rows) for (c in 0..COLS) {
        var a = 0f
        var k = 0
        for (rr in (r - 1)..(r + 1)) for (cc in (c - 1)..(c + 1)) {
            if (rr in 0..rows && cc in 0..COLS) { a += g[rr * (COLS + 1) + cc]; k++ }
        }
        o[r * (COLS + 1) + c] = sm(0.15f, 0.7f, a / k)
    }
    return o
}

private class Pose(val P: CharProfile, val iw: Float, val ih: Float) {
    val k = iw / 768f
    var t = 0f
    var sway = 0f
    var breath = 0f
    var earL = 0f
    var earR = 0f
    var ahoge = 0f
    var talk = 0f
    var talkSmooth = 0f
    var mouth = 0f
    var dx = 0f
    var dy = 0f

    fun update(time: Float, talkLevel: Float) {
        t = time
        sway = sin(time * TAU / 5.2f)
        breath = sin(time * TAU / 3.6f)
        earL = twitch(time, 4.9f, 0f)
        earR = twitch(time, 6.1f, 2.0f)
        ahoge = sin(time * TAU / 2.4f)
        talkSmooth += (talkLevel.coerceIn(0f, 1f) - talkSmooth) * 0.18f
        talk = talkSmooth
        // lip-sync: quick attack, slightly slower release, so the mouth snaps open on a syllable and relaxes between them
        val target = (talkLevel * 2.2f).coerceIn(0f, 1f)
        mouth += (target - mouth) * (if (target > mouth) 0.65f else 0.30f)
        if (mouth < 0.01f && target == 0f) mouth = 0f
    }

    private fun twitch(time: Float, period: Float, offset: Float): Float {
        val p = (time + offset) % period
        return if (p < 0.45f) sin(p / 0.45f * TAU * 1.5f) * (1f - p / 0.45f) else 0f
    }

    private fun rot(x: Float, y: Float, px: Float, py: Float, ang: Float, w: Float) {
        if (w <= 0f || ang == 0f) return
        val rx = x - px
        val ry = y - py
        val c = cos(ang)
        val s = sin(ang)
        dx += ((rx * c - ry * s) - rx) * w
        dy += ((rx * s + ry * c) - ry) * w
    }

    /** Displacement (dx, dy) of the picture point (x, y), in picture pixels. */
    fun warp(x: Float, y: Float, hairW: Float = 1f) {
        dx = 0f; dy = 0f

        // 1. body sway: rotation around the hips (or the bottom edge of a portrait), the lower part stays planted
        val wb = sm(P.pivotY, P.swayTop, y)
        dx += sway * 0.008f * (P.pivotY - y) * wb
        dy += sway * 0.008f * (x - P.cx) * wb

        // 2. breathing: upper body lifts, chest widens
        dy -= breath * 3.5f * k * sm(P.breathBot, P.breathTop, y)
        dx += breath * 0.010f * (x - P.cx) * bell(y, P.chestY, P.chestW)

        // 3. talking nod (head only)
        dy += talk * 5f * k * sm(P.headBot, P.headTop, y)

        // 4. hair: the long hair on both sides swings, more towards the tips
        // (classic art: only real pink hair moves, hairW = how much hair is under this point; other art: the x ranges of the profile)
        val hw = sm(P.hY0, P.hY1, y) * (1f - 0.5f * sm(P.hY2, P.hY3, y)) * hairW
        val left = sm(P.lA, P.lB, x)
        val right = sm(P.rA, P.rB, x) * (1f - sm(P.rC, P.rD, x))
        val ph = if (x < P.cx) 0f else 1.7f
        val swing = sin(t * TAU / 3.1f - y * 0.0045f + ph) + 0.35f * sin(t * TAU / 1.7f - y * 0.006f + ph * 2f)
        dx += swing * 5.5f * k * hw * (left + right)
        dy += swing * 1.2f * k * hw * (left + right)

        // 4b. v2.46: hair zones of the photo-style models (soft ellipses, the top stays, the tips swing)
        val hz = P.hairZones
        if (hz != null) {
            var zi = 0
            while (zi + 3 < hz.size) {
                val zw = ell(x, y, hz[zi], hz[zi + 1], hz[zi + 2], hz[zi + 3])
                if (zw > 0f) {
                    val tip = ((y - (hz[zi + 1] - hz[zi + 3])) / (2f * hz[zi + 3])).coerceIn(0f, 1f)
                    val zph = if (hz[zi] < P.cx) 0f else 1.7f
                    val zs = sin(t * TAU / 3.1f - y * 0.0045f + zph) + 0.35f * sin(t * TAU / 1.7f - y * 0.006f + zph * 2f)
                    dx += zs * 5.5f * k * zw * tip
                    dy += zs * 1.2f * k * zw * tip
                }
                zi += 4
            }
        }

        // 5. ears (cat ears, hood ears), the ahoge / hair clip
        val el = P.earL
        if (el != null) rot(x, y, el[0], el[1], earL * 0.17f, ell(x, y, el[2], el[3], el[4], el[5]))
        val er = P.earR
        if (er != null) rot(x, y, er[0], er[1], -earR * 0.17f, ell(x, y, er[2], er[3], er[4], er[5]))
        val ah = P.ahoge
        if (ah != null) rot(x, y, ah[0], ah[1], ahoge * 0.12f, ell(x, y, ah[2], ah[3], ah[4], ah[5]))

        // keep the picture's own border still so no gap ever shows
        val e = 40f * k
        val edge = sm(0f, e, x) * sm(iw, iw - e, x) * sm(0f, e, y) * sm(ih, ih - e, y)
        dx *= edge
        dy *= edge
    }
}

/** 0 = open, 1 = closed. Two timers with different periods give a natural, irregular blink. */
private fun blink(t: Float): Float {
    fun one(p: Float): Float = if (p < 0.17f) sin(p / 0.17f * PI_F) else 0f
    return max(one(t % 3.7f), one((t + 1.3f) % 5.9f))
}

private fun DrawScope.drawEyelid(sx: Float, sy: Float, w: Float, h: Float, tilt: Float, c: Float, skinTop: Color, skinBot: Color, lash: Color) {
    if (c <= 0.03f) return
    withTransform({ translate(sx, sy); rotate(tilt, Offset.Zero) }) {
        // the lid is painted as 3 soft layers (big + faint -> small + solid) so its edge melts into the cheek
        val layers = floatArrayOf(1.28f, 0.18f, 1.14f, 0.42f, 1.0f, 1.0f)
        var li = 0
        while (li < layers.size) {
            val sc = layers[li]
            val al = layers[li + 1]
            li += 2
            val ow = w * sc
            val oh = h * sc
            val oval = Path().apply { addOval(Rect(-ow, -oh, ow, oh)) }
            val top = -oh - 1f
            val bottom = top + (2f * oh + 2f) * c
            clipPath(oval) {
                drawRect(
                    Brush.verticalGradient(listOf(skinTop.copy(alpha = al), skinBot.copy(alpha = al)), startY = -oh, endY = oh),
                    topLeft = Offset(-ow - 2f, top), size = Size(2f * ow + 4f, bottom - top)
                )
            }
        }
        val bottom = -h - 1f + (2f * h + 2f) * c
        val a = sm(0.25f, 0.6f, c)
        if (a > 0f) {
            val ly = if (bottom < h * 0.35f) bottom else h * 0.35f
            val p = Path().apply {
                moveTo(-w * 0.90f, ly - h * 0.20f)
                quadraticBezierTo(0f, ly + h * 0.50f, w * 0.90f, ly - h * 0.20f)
            }
            drawPath(p, lash.copy(alpha = a), style = Stroke(width = max(2.4f, h * 0.17f), cap = StrokeCap.Round))
        }
    }
}

private val SKIN_MOUTH = Color(0xFFFFE6D6)
private val MOUTH_IN = Color(0xFF7B2B38)
private val MOUTH_EDGE = Color(0xFF4E1D26)
private val TONGUE = Color(0xFFEE8C98)

/**
 * Mouth. Units are picture pixels, (sx, sy) = mouth centre on screen, s = picture-to-screen scale.
 * [open] = how far the voice opens it (lip-sync); [f] = the current face numbers (mood) which choose the closed-mouth shape
 * (smile, frown, grit, pout, cat smile ...) and a resting open amount (surprise).
 */
private fun DrawScope.drawMouth(sx: Float, sy: Float, s: Float, open: Float, t: Float, f: FloatArray, skin: Color, pw: Float, ph: Float, rotDeg: Float) {
    val eo = max(open, f[F_OPEN])
    val shape = f[F_SHAPE]
    val fadeAll = max(sm(0.03f, 0.14f, eo), shape)
    if (fadeAll <= 0.03f) return
    withTransform({ translate(sx, sy); rotate(rotDeg, Offset.Zero); scale(s, s, Offset.Zero) }) {
        // 1. hide the drawn smile line (3 soft layers so the patch has no hard edge)
        val patch = floatArrayOf(1.3f, 0.30f, 1.15f, 0.65f, 1.0f, 1.0f)
        var i = 0
        while (i < patch.size) {
            val sc = patch[i]
            val al = patch[i + 1] * fadeAll
            i += 2
            drawOval(skin.copy(alpha = al), Offset(-17f * sc * pw, -6.5f * sc * ph), Size(34f * sc * pw, 13f * sc * ph))
        }

        // 2. closed mouth shape of the current mood (fades out while the mouth is open)
        val closed = (1f - sm(0.03f, 0.2f, eo)) * shape
        if (closed > 0.03f) {
            val w = f[F_MW]
            val c = f[F_CURVE]
            val wavy = f[F_WAVY]
            val cat = f[F_CAT]
            val teeth = f[F_TEETH]
            val stroke = Stroke(width = 1.7f, cap = StrokeCap.Round)
            if (teeth > 0.05f) {
                val a = teeth * closed
                drawRoundRect(Color.White.copy(alpha = 0.95f * a), Offset(-w * 0.8f, -2.4f), Size(w * 1.6f, 4.8f), androidx.compose.ui.geometry.CornerRadius(1.6f, 1.6f))
                drawRoundRect(MOUTH_EDGE.copy(alpha = a), Offset(-w * 0.8f, -2.4f), Size(w * 1.6f, 4.8f), androidx.compose.ui.geometry.CornerRadius(1.6f, 1.6f), style = Stroke(width = 1.2f))
                drawLine(MOUTH_EDGE.copy(alpha = 0.8f * a), Offset(-w * 0.8f, 0f), Offset(w * 0.8f, 0f), strokeWidth = 0.9f)
                var tx = -w * 0.4f
                while (tx < w * 0.8f) { drawLine(MOUTH_EDGE.copy(alpha = 0.7f * a), Offset(tx, -2.4f), Offset(tx, 2.4f), strokeWidth = 0.8f); tx += w * 0.4f }
            } else {
                val line = Path().apply {
                    moveTo(-w, 0f)
                    cubicTo(-w * 0.5f, c * 2f - 3f * wavy, w * 0.5f, c * 2f + 3f * wavy, w, 0f)
                }
                drawPath(line, MOUTH_LINE.copy(alpha = closed * (1f - cat)), style = stroke)
            }
            if (cat > 0.05f) {
                val cp = Path().apply {
                    moveTo(-w * 0.9f, 0f)
                    quadraticBezierTo(-w * 0.45f, c * 1.6f, 0f, 0f)
                    quadraticBezierTo(w * 0.45f, c * 1.6f, w * 0.9f, 0f)
                }
                drawPath(cp, MOUTH_LINE.copy(alpha = closed * cat), style = stroke)
            }
        }

        // 3. the open mouth: width and height follow the voice, a little wobble makes "a / o / e" shapes
        val fadeIn = sm(0.03f, 0.14f, eo)
        if (fadeIn <= 0.02f) return@withTransform
        val wobAmt = if (open >= f[F_OPEN]) 0.25f else 0.04f
        val wob = 1f + wobAmt * (0.6f * sin(t * 9.3f) + 0.4f * sin(t * 14.7f + 1f))
        val w = (4.5f + 5.5f * eo) * wob
        val hh = 0.9f + 6.5f * eo
        val mouth = Path().apply {
            moveTo(-w, 0f)
            quadraticBezierTo(0f, -hh * 0.9f, w, 0f)
            quadraticBezierTo(0f, hh * 2.1f, -w, 0f)
            close()
        }
        drawPath(mouth, MOUTH_IN.copy(alpha = fadeIn))
        clipPath(mouth) {
            if (hh > 2.2f) drawOval(TONGUE.copy(alpha = fadeIn), Offset(-w * 0.55f, hh * 0.30f), Size(w * 1.1f, hh * 1.3f))
            if (hh > 3.0f) drawRect(Color.White.copy(alpha = 0.92f * fadeIn), Offset(-w * 0.7f, -hh * 0.42f), Size(w * 1.4f, 1.5f))
        }
        drawPath(mouth, MOUTH_EDGE.copy(alpha = fadeIn), style = Stroke(width = 1.1f, cap = StrokeCap.Round))
    }
}

// ---------------------------------------------------------------------------------------------------------------
// v2.34 emotions. The AI calls set_emotion(happy|excited|calm|sad|love|surprised|angry|jealous|sulky|playful|worried);
// every mood is a small set of numbers (eyebrows, eyelids, mouth shape, blush ...) and the face eases towards them.
// ---------------------------------------------------------------------------------------------------------------
private const val F_BROW = 0      // eyebrow opacity (the bangs hide natural brows, so they are only drawn when the mood needs them)
private const val F_BTILT = 1     // + = inner end up (sad / worried), - = inner end down (angry)
private const val F_BY = 2        // eyebrow height, - = raised
private const val F_LID = 3       // steady eyelid closure 0..1 (sleepy / narrowed eyes)
private const val F_LTILT = 4     // eyelid slant in degrees, + = inner corner lower (angry), - = outer corner lower (sad)
private const val F_CURVE = 5     // mouth curve, + = smile, - = frown
private const val F_MW = 6        // mouth half width
private const val F_OPEN = 7      // resting open amount of the mouth (surprise, laugh)
private const val F_TEETH = 8     // gritted teeth (anger)
private const val F_WAVY = 9      // wobbly mouth (worried, jealous)
private const val F_CAT = 10      // cat smile "w"
private const val F_BLUSH = 11
private const val F_HEART = 12    // heart eyes
private const val F_SPARK = 13    // sparkling eyes
private const val F_TEAR = 14
private const val F_ANGER = 15    // anger vein mark
private const val F_SWEAT = 16
private const val F_WINK = 17
private const val F_GLOOM = 18    // dark gloom lines on the forehead (jealous)
private const val F_SHAPE = 19    // 1 = draw our own mouth instead of the smile that is painted in the artwork
private const val F_N = 20

private fun faceTarget(emotion: String): FloatArray {
    val f = FloatArray(F_N)
    when (emotion.trim().lowercase()) {
        "happy" -> { f[F_LID] = 0.12f; f[F_CURVE] = 6f; f[F_MW] = 11f; f[F_BLUSH] = 0.45f; f[F_SPARK] = 0.5f; f[F_SHAPE] = 1f }
        "excited" -> { f[F_BROW] = 0.5f; f[F_BY] = -6f; f[F_BTILT] = 2f; f[F_LID] = 0.04f; f[F_CURVE] = 7f; f[F_MW] = 12f; f[F_OPEN] = 0.45f
            f[F_BLUSH] = 0.55f; f[F_SPARK] = 1f; f[F_SHAPE] = 1f }
        "sad" -> { f[F_BROW] = 0.85f; f[F_BTILT] = 7f; f[F_LID] = 0.30f; f[F_LTILT] = -10f; f[F_CURVE] = -5f; f[F_MW] = 7f
            f[F_TEAR] = 1f; f[F_SHAPE] = 1f }
        "love" -> { f[F_LID] = 0.08f; f[F_CURVE] = 6f; f[F_MW] = 9f; f[F_BLUSH] = 1f; f[F_HEART] = 1f; f[F_SHAPE] = 1f }
        "surprised" -> { f[F_BROW] = 0.8f; f[F_BY] = -9f; f[F_BTILT] = 1f; f[F_OPEN] = 0.55f; f[F_SPARK] = 0.3f; f[F_SHAPE] = 1f }
        "angry" -> { f[F_BROW] = 1f; f[F_BTILT] = -7f; f[F_LID] = 0.32f; f[F_LTILT] = 13f; f[F_CURVE] = -1.5f; f[F_MW] = 9f
            f[F_TEETH] = 1f; f[F_ANGER] = 1f; f[F_BLUSH] = 0.15f; f[F_SHAPE] = 1f }
        "jealous" -> { f[F_BROW] = 0.8f; f[F_BTILT] = -3f; f[F_LID] = 0.30f; f[F_LTILT] = 4f; f[F_CURVE] = -2f; f[F_MW] = 7f
            f[F_WAVY] = 0.3f; f[F_BLUSH] = 0.45f; f[F_GLOOM] = 1f; f[F_SHAPE] = 1f }
        "sulky" -> { f[F_BROW] = 0.7f; f[F_BTILT] = -2f; f[F_LID] = 0.20f; f[F_LTILT] = 5f; f[F_CURVE] = -3f; f[F_MW] = 5f
            f[F_BLUSH] = 0.8f; f[F_SHAPE] = 1f }
        "playful" -> { f[F_CURVE] = 3f; f[F_MW] = 9f; f[F_CAT] = 1f; f[F_WINK] = 1f; f[F_BLUSH] = 0.4f; f[F_SPARK] = 0.4f; f[F_SHAPE] = 1f }
        "worried" -> { f[F_BROW] = 0.9f; f[F_BTILT] = 8f; f[F_LID] = 0.10f; f[F_CURVE] = -2f; f[F_MW] = 7f; f[F_WAVY] = 1f
            f[F_SWEAT] = 1f; f[F_SHAPE] = 1f }
        else -> { }   // calm: the artwork's own gentle smile
    }
    return f
}

private val BROW_COL = Color(0xFF8C4A58)
private val MOUTH_LINE = Color(0xFF8E4651)

private fun DrawScope.drawBrow(sx: Float, sy: Float, s: Float, left: Boolean, tilt: Float, alpha: Float) {
    if (alpha <= 0.03f) return
    val dir = if (left) 1f else -1f                       // the inner end of the left brow is on its right
    val innerX = sx + dir * 13f * s
    val innerY = sy - tilt * s
    val outerX = sx - dir * 13f * s
    val outerY = sy + tilt * 0.45f * s
    val p = Path().apply {
        moveTo(outerX, outerY)
        quadraticBezierTo(sx, sy - tilt * 0.2f * s - 2.2f * s, innerX, innerY)
    }
    drawPath(p, BROW_COL.copy(alpha = alpha * 0.7f), style = Stroke(width = 2.8f * s, cap = StrokeCap.Round))
}

private fun DrawScope.drawBlush(cx: Float, cy: Float, s: Float, a: Float, col: Color) {
    if (a <= 0.03f) return
    val rx = 23f * s
    withTransform({ scale(1f, 0.55f, Offset(cx, cy)) }) {
        drawCircle(Brush.radialGradient(listOf(col.copy(alpha = a * 0.55f), Color.Transparent), center = Offset(cx, cy), radius = rx), rx, Offset(cx, cy))
    }
}

private fun heartPath(cx: Float, cy: Float, r: Float): Path = Path().apply {
    moveTo(cx, cy + r * 0.9f)
    cubicTo(cx - r * 1.6f, cy - r * 0.2f, cx - r * 0.7f, cy - r * 1.4f, cx, cy - r * 0.45f)
    cubicTo(cx + r * 0.7f, cy - r * 1.4f, cx + r * 1.6f, cy - r * 0.2f, cx, cy + r * 0.9f)
    close()
}

private fun DrawScope.drawHeartEye(cx: Float, cy: Float, s: Float, a: Float, t: Float) {
    if (a <= 0.03f) return
    val pulse = 1f + 0.10f * sin(t * 6f)
    drawCircle(Color(0xFFFFD9E6).copy(alpha = 0.80f * a), 12.5f * s, Offset(cx, cy))
    drawPath(heartPath(cx, cy, 7.5f * s * pulse), Color(0xFFFF3D87).copy(alpha = a))
    drawCircle(Color.White.copy(alpha = 0.9f * a), 1.6f * s, Offset(cx - 3f * s, cy - 3f * s))
}

private fun DrawScope.drawStar(cx: Float, cy: Float, r: Float, a: Float) {
    if (a <= 0.03f) return
    val col = Color.White.copy(alpha = a)
    drawLine(col, Offset(cx - r, cy), Offset(cx + r, cy), strokeWidth = r * 0.45f, cap = StrokeCap.Round)
    drawLine(col, Offset(cx, cy - r), Offset(cx, cy + r), strokeWidth = r * 0.45f, cap = StrokeCap.Round)
    drawCircle(col, r * 0.42f, Offset(cx, cy))
}

private fun DrawScope.drawTear(sx: Float, sy: Float, s: Float, t: Float, a: Float, phase: Float) {
    if (a <= 0.03f) return
    val prog = ((t + phase) % 2.4f) / 2.4f
    val y = sy + prog * 46f * s
    val al = a * sm(0f, 0.1f, prog) * (1f - sm(0.7f, 1f, prog))
    if (al <= 0.02f) return
    drawLine(Color(0xFFBFE3FF).copy(alpha = 0.35f * al), Offset(sx, sy), Offset(sx, y), strokeWidth = 1.6f * s, cap = StrokeCap.Round)
    drawCircle(Color(0xFFBFE3FF).copy(alpha = 0.85f * al), 2.8f * s, Offset(sx, y))
    drawCircle(Color.White.copy(alpha = 0.9f * al), 1.0f * s, Offset(sx - 0.8f * s, y - 0.8f * s))
}

private fun DrawScope.drawSweat(cx: Float, cy0: Float, s: Float, t: Float, a: Float) {
    if (a <= 0.03f) return
    val cy = cy0 + sin(t * 3f) * 2f * s
    val p = Path().apply {
        moveTo(cx, cy - 9f * s)
        cubicTo(cx + 7f * s, cy - 1f * s, cx + 6f * s, cy + 6f * s, cx, cy + 6f * s)
        cubicTo(cx - 6f * s, cy + 6f * s, cx - 7f * s, cy - 1f * s, cx, cy - 9f * s)
        close()
    }
    drawPath(p, Color(0xFFB7E4FF).copy(alpha = 0.88f * a))
    drawPath(p, Color(0xFF6AAAD8).copy(alpha = a), style = Stroke(width = 1.1f * s))
    drawCircle(Color.White.copy(alpha = 0.9f * a), 1.4f * s, Offset(cx - 2f * s, cy + 1f * s))
}

private fun DrawScope.drawAnger(cx: Float, cy: Float, s: Float, t: Float, a: Float) {
    if (a <= 0.03f) return
    val r = 7f * s * (1f + 0.12f * sin(t * 9f))
    val col = Color(0xFFE53935).copy(alpha = a)
    for (qx in floatArrayOf(-1f, 1f)) {
        for (qy in floatArrayOf(-1f, 1f)) {
            val p = Path().apply {
                moveTo(cx + qx * r, cy + qy * r * 0.2f)
                quadraticBezierTo(cx + qx * r * 0.25f, cy + qy * r * 0.25f, cx + qx * r * 0.2f, cy + qy * r)
            }
            drawPath(p, col, style = Stroke(width = 2.3f * s, cap = StrokeCap.Round))
        }
    }
}

private fun DrawScope.drawGloom(sx: Float, sy: Float, s: Float, a: Float) {
    if (a <= 0.03f) return
    val col = Color(0xFF5B3A8C).copy(alpha = 0.38f * a)
    for (i in 0 until 7) {
        val x = sx + i * 15f * s
        val len = (14f + (i % 3) * 7f) * s
        drawLine(col, Offset(x, sy), Offset(x + 1.5f * s, sy + len), strokeWidth = 2.2f * s, cap = StrokeCap.Round)
    }
}

private val SPARKS = arrayOf(
    floatArrayOf(0.12f, 0.30f), floatArrayOf(0.22f, 0.17f), floatArrayOf(0.86f, 0.44f), floatArrayOf(0.78f, 0.28f),
    floatArrayOf(0.09f, 0.60f), floatArrayOf(0.91f, 0.68f), floatArrayOf(0.34f, 0.09f), floatArrayOf(0.66f, 0.10f)
)

/**
 * The animated character. Fills its parent: the artwork is fitted inside (never cropped, never stretched), the
 * edges melt into [fade] (the app background colour) and petals / sparkles float over everything.
 *
 * @param profile which artwork and which face / body numbers to use (Characters.kt).
 * @param emotion the AI's current mood (set_emotion): happy, excited, calm, sad, love, surprised, angry, jealous, sulky, playful, worried.
 * @param speech 0..1 loudness of the assistant's own voice right now (0 = silent). Drives the lip-sync and the head nod.
 */
@Composable
fun AnimeCharacter(profile: CharProfile, modifier: Modifier = Modifier, speech: () -> Float = { 0f }, emotion: String = "calm", fade: Color = YasminUi.Bg) {
    val ctx = LocalContext.current
    val bmp = remember(profile.id) {
        try {
            val rid = ctx.resources.getIdentifier(profile.res, "drawable", ctx.packageName)
            if (rid == 0) null else BitmapFactory.decodeResource(ctx.resources, rid, BitmapFactory.Options().apply { inScaled = false })
        } catch (e: Throwable) { null }
    } ?: return
    val iw = bmp.width.toFloat()
    val ih = bmp.height.toFloat()
    val rows = Math.round(COLS * ih / iw).coerceAtLeast(8)
    val pose = remember(profile.id) { Pose(profile, iw, ih) }
    val face = remember { FloatArray(F_N) }
    val hairW = remember(bmp) {
        if (!profile.hairByColor) FloatArray((COLS + 1) * (rows + 1)) { 1f }
        else try { hairWeights(bmp, rows) } catch (e: Throwable) { FloatArray((COLS + 1) * (rows + 1)) { 1f } }
    }
    val verts = remember(rows) { FloatArray((COLS + 1) * (rows + 1) * 2) }
    val paint = remember { Paint().apply { isFilterBitmap = true; isAntiAlias = true } }
    val tintPaint = remember { Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN) } }
    // alpha mask of the background (1 = background, 0 = the character), made from the artwork; the same mesh moves it, so it follows the sway.
    // Only the classic artwork has one; the other characters have no tinted background.
    val maskBmp = remember(profile.id) {
        try {
            val mn = profile.mask
            if (mn == null) null else {
                val id = ctx.resources.getIdentifier(mn, "drawable", ctx.packageName)
                if (id == 0) null else BitmapFactory.decodeResource(ctx.resources, id, BitmapFactory.Options().apply { inScaled = false })
            }
        } catch (e: Throwable) { null }
    }
    val skinTop = remember(profile.id) { Color(profile.skinTop) }
    val skinBot = remember(profile.id) { Color(profile.skinBot) }
    val skinMouth = remember(profile.id) { Color(profile.skinMouth) }
    val lash = remember(profile.id) { Color(profile.lash) }

    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var start = -1L
        while (true) {
            withFrameNanos { n ->
                if (start < 0L) start = n
                tick = n - start
            }
        }
    }

    Canvas(modifier.clipToBounds()) {
        val P = profile
        val fs = P.fs                    // mouth / brows / blush / extras scale
        val es = P.lidW / 16.5f          // eye-sized extras (heart eyes, sparkles) scale
        val time = tick / 1_000_000_000f
        pose.update(time, speech())
        // ease every face number towards the current mood (about 0.3 s), so a mood change melts instead of jumping
        val goal = faceTarget(emotion)
        for (q in 0 until F_N) face[q] += (goal[q] - face[q]) * 0.10f

        // fit the artwork inside the canvas, centred
        // v2.46: "cover" models fill the whole screen (the picture is cropped a little at the sides), the classic art is fitted inside
        val s = if (P.cover) maxOf(size.width / iw, size.height / ih) else minOf(size.width / iw, size.height / ih)
        val offX = (size.width - iw * s) / 2f
        val offY = if (P.cover) (size.height - ih * s) * 0.3f else (size.height - ih * s) / 2f

        // ---- deformed mesh
        var k = 0
        for (r in 0..rows) {
            val y = ih * r / rows
            for (c in 0..COLS) {
                val x = iw * c / COLS
                pose.warp(x, y, hairW[r * (COLS + 1) + c])
                verts[k++] = offX + (x + pose.dx) * s
                verts[k++] = offY + (y + pose.dy) * s
            }
        }
        drawContext.canvas.nativeCanvas.drawBitmapMesh(bmp, COLS, rows, verts, 0, null, 0, paint)

        // ---- slowly changing colour filter on the background only
        if (maskBmp != null) {
            val nc = drawContext.canvas.nativeCanvas
            val layer = nc.saveLayerAlpha(null, 84)
            nc.drawBitmapMesh(maskBmp, COLS, rows, verts, 0, null, 0, paint)
            tintPaint.color = tintAt(time).toArgb()
            nc.drawRect(0f, 0f, size.width, size.height, tintPaint)
            nc.restoreToCount(layer)
        }

        // ---- face: everything below follows the deformed picture, so it moves with the head
        fun scr(px: Float, py: Float): Offset {
            pose.warp(px, py)
            return Offset(offX + (px + pose.dx) * s, offY + (py + pose.dy) * s)
        }
        val bl = blink(time)
        val lidBase = face[F_LID] + (1f - face[F_LID]) * bl
        val lidL = lidBase
        val wp = time % 3.4f
        val lidR = max(lidBase, face[F_WINK] * sm(0f, 0.15f, wp) * (1f - sm(0.9f, 1.1f, wp)))
        val eyeL = scr(P.eLx, P.eLy)
        val eyeR = scr(P.eRx, P.eRy)

        // gloom lines (jealous) sit on the forehead, under everything else
        val gl = scr(P.eLx - 18f * fs, P.eLy - 58f * fs)
        drawGloom(gl.x, gl.y, s * fs, face[F_GLOOM])

        // blush on the cheeks
        val warm = Color(0xFFFF6F8F)
        val bc = Color(0xFFFF5470).copy(alpha = 1f)
        val chL = scr(P.eLx - 16f * fs, P.eLy + 22f * fs)
        val chR = scr(P.eRx + 12f * fs, P.eRy + 22f * fs)
        drawBlush(chL.x, chL.y, s * fs, face[F_BLUSH], if (face[F_ANGER] > 0.5f) bc else warm)
        drawBlush(chR.x, chR.y, s * fs, face[F_BLUSH], if (face[F_ANGER] > 0.5f) bc else warm)

        // sparkling or heart eyes (under the eyelids, so blinks still close over them)
        val eyeOpen = 1f - lidBase * 1.2f
        if (face[F_HEART] > 0.03f) {
            drawHeartEye(eyeL.x, eyeL.y, s * es, face[F_HEART] * eyeOpen.coerceIn(0f, 1f), time)
            drawHeartEye(eyeR.x, eyeR.y, s * es, face[F_HEART] * eyeOpen.coerceIn(0f, 1f), time)
        }
        if (face[F_SPARK] > 0.03f) {
            val pk = face[F_SPARK] * eyeOpen.coerceIn(0f, 1f)
            val r1 = (3.6f + 1.6f * sin(time * 5f)) * s * es
            val r2 = (3.6f + 1.6f * sin(time * 5f + 1.7f)) * s * es
            drawStar(eyeL.x + 5f * s * es, eyeL.y - 5f * s * es, r1, pk)
            drawStar(eyeR.x + 5f * s * es, eyeR.y - 5f * s * es, r2, pk)
        }

        // eyelids: blinking + the mood's own droop / slant
        drawEyelid(eyeL.x, eyeL.y, P.lidW * s, P.lidH * s, P.lidTiltL + face[F_LTILT], lidL, skinTop, skinBot, lash)
        drawEyelid(eyeR.x, eyeR.y, P.lidW * 1.06f * s, P.lidH * 1.08f * s, P.lidTiltR - face[F_LTILT], lidR, skinTop, skinBot, lash)

        // eyebrows
        val bL = scr(P.eLx - 1f * fs, P.eLy - 28f * fs + face[F_BY] * fs)
        val bR = scr(P.eRx + 3f * fs, P.eRy - 27f * fs + face[F_BY] * fs)
        drawBrow(bL.x, bL.y, s * fs, true, face[F_BTILT], face[F_BROW])
        drawBrow(bR.x, bR.y, s * fs, false, face[F_BTILT], face[F_BROW])

        // mouth (mood shape + lip-sync)
        val mp = scr(P.mx, P.my)
        drawMouth(mp.x, mp.y, s * fs, pose.mouth, time, face, skinMouth, P.patchW, P.patchH, P.mouthRot)

        // extras: tears, sweat drop, anger mark
        val tL = scr(P.eLx - 2f * fs, P.eLy + 15f * fs)
        val tR = scr(P.eRx + 1f * fs, P.eRy + 16f * fs)
        drawTear(tL.x, tL.y, s * fs, time, face[F_TEAR], 0f)
        drawTear(tR.x, tR.y, s * fs, time, face[F_TEAR], 1.1f)
        val sw = scr(P.eRx + 35f * fs, P.eRy - 19f * fs)
        drawSweat(sw.x, sw.y, s * fs, time, face[F_SWEAT])
        val an = scr(P.eRx + 32f * fs, P.eRy - 53f * fs)
        drawAnger(an.x, an.y, s * fs, time, face[F_ANGER])

        // ---- cover models: dark scrims top and bottom so the title, mic and text stay readable on any picture
        if (P.cover) {
            drawRect(Brush.verticalGradient(listOf(fade.copy(alpha = 0.92f), Color.Transparent), startY = 0f, endY = size.height * 0.2f), Offset(0f, 0f), Size(size.width, size.height * 0.2f))
            val sb = size.height * 0.3f
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, fade.copy(alpha = 0.95f)), startY = size.height - sb, endY = size.height), Offset(0f, size.height - sb), Size(size.width, sb))
        }

        // ---- melt the borders into the app background
        val imgW = iw * s
        val imgH = ih * s
        val fv = imgH * 0.10f
        if (!P.cover) drawRect(Brush.verticalGradient(listOf(fade, Color.Transparent), startY = offY, endY = offY + fv), Offset(0f, offY), Size(size.width, fv))
        val fb = imgH * 0.10f
        if (!P.cover) drawRect(Brush.verticalGradient(listOf(Color.Transparent, fade), startY = offY + imgH - fb, endY = offY + imgH), Offset(0f, offY + imgH - fb), Size(size.width, fb))
        if (offX > 1f && !P.cover) {
            val fh = imgW * 0.06f
            drawRect(Brush.horizontalGradient(listOf(fade, Color.Transparent), startX = offX, endX = offX + fh), Offset(offX, offY), Size(fh, imgH))
            drawRect(Brush.horizontalGradient(listOf(Color.Transparent, fade), startX = offX + imgW - fh, endX = offX + imgW), Offset(offX + imgW - fh, offY), Size(fh, imgH))
            drawRect(fade, Offset(0f, 0f), Size(offX, size.height))
            drawRect(fade, Offset(offX + imgW, 0f), Size(size.width - offX - imgW, size.height))
        }

        // ---- cherry petals drifting down from the blossom tree (top right)
        if (P.petals) for (i in 0 until 16) {
            val fx = (i * 0.6180339f) % 1f
            val speed = 0.030f + 0.028f * ((i * 7) % 5) / 5f
            val prog = (time * speed + fx * 1.7f) % 1.15f
            val py = (prog - 0.08f) * size.height * 0.9f
            val px = size.width * (0.42f + 0.62f * fx) - prog * size.width * 0.24f + sin(time * 0.9f + i) * 14.dp.toPx()
            val a = sm(0f, 0.08f, prog) * sm(1.15f, 1.0f, prog)
            val rr = (3.4f + (i % 3) * 1.4f).dp.toPx()
            withTransform({ translate(px, py); rotate(time * 38f * (1 + i % 3) + i * 40f, Offset.Zero) }) {
                drawOval(Color(0xFFFFB3CE).copy(alpha = a * 0.85f), Offset(-rr, -rr * 0.55f), Size(2f * rr, 1.1f * rr))
                drawOval(Color.White.copy(alpha = a * 0.45f), Offset(-rr * 0.5f, -rr * 0.3f), Size(rr, rr * 0.45f))
            }
        }

        // ---- twinkling sparkles
        for (i in SPARKS.indices) {
            val v = sin(time * 1.6f + i * 1.3f)
            val a = if (v > 0f) v * v else 0f
            if (a < 0.02f) continue
            val cx = size.width * SPARKS[i][0]
            val cy = size.height * SPARKS[i][1]
            val rr = (3f + 5f * a).dp.toPx()
            val col = Color.White.copy(alpha = a * 0.9f)
            drawLine(col, Offset(cx - rr, cy), Offset(cx + rr, cy), strokeWidth = 1.4f.dp.toPx(), cap = StrokeCap.Round)
            drawLine(col, Offset(cx, cy - rr), Offset(cx, cy + rr), strokeWidth = 1.4f.dp.toPx(), cap = StrokeCap.Round)
            drawCircle(Color(0xFFBFE6FF).copy(alpha = a * 0.5f), rr * 0.45f, Offset(cx, cy))
        }
    }
}
