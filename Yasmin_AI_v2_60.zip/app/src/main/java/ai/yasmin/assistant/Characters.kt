package ai.yasmin.assistant

import android.content.Context

/*
 * v2.43, every character the home page can show. One CharProfile = one artwork + the numbers the animation needs for it
 * (where the eyes / mouth are, how big the eyelids are, skin colours for the closed eyelid, where the hair and ears are).
 * All positions are in artwork pixels (the width of the artwork, 768-777 px, is what the numbers were measured on).
 * The classic pink cat-ear Yasmin keeps exactly the numbers AnimeCharacter.kt used before (the defaults below).
 *
 * To add another character: put the picture in res/drawable-nodpi, measure its eye / mouth centres, add one CharProfile here.
 */
class CharProfile(
    val id: String,
    val label: String,
    val res: String,                      // drawable name
    val mask: String? = null,             // background mask (only the classic art has one)
    // face landmarks
    val eLx: Float = 351f, val eLy: Float = 260f,
    val eRx: Float = 420f, val eRy: Float = 251f,
    val mx: Float = 390f, val my: Float = 298f,
    val lidW: Float = 16.5f, val lidH: Float = 12.5f,        // half size of the left eyelid (the right one is a little bigger)
    val lidTiltL: Float = 4f, val lidTiltR: Float = -8f,
    val skinTop: Long = 0xFFFFE8D7, val skinBot: Long = 0xFFFED6C6, val skinMouth: Long = 0xFFFFE6D6, val lash: Long = 0xFF6B3036,
    val fs: Float = 1f,                   // size of mouth / brows / blush / extras relative to the classic art
    val patchW: Float = 1f, val patchH: Float = 1f,           // size of the skin patch that hides the painted mouth
    val mouthRot: Float = -7f,
    // body
    val cx: Float = 384f,
    val pivotY: Float = 1180f, val swayTop: Float = 520f,
    val breathBot: Float = 1000f, val breathTop: Float = 400f, val chestY: Float = 560f, val chestW: Float = 170f,
    val headBot: Float = 520f, val headTop: Float = 200f,
    // hair swing: y range and the x ranges of the left / right hair
    val hairByColor: Boolean = true,
    val hY0: Float = 180f, val hY1: Float = 600f, val hY2: Float = 640f, val hY3: Float = 780f,
    val lA: Float = 345f, val lB: Float = 255f,
    val rA: Float = 440f, val rB: Float = 530f, val rC: Float = 630f, val rD: Float = 690f,
    // ears: [pivotX, pivotY, centreX, centreY, radiusX, radiusY]
    val earL: FloatArray? = floatArrayOf(330f, 170f, 308f, 158f, 28f, 30f),
    val earR: FloatArray? = floatArrayOf(425f, 165f, 435f, 138f, 26f, 32f),
    val ahoge: FloatArray? = floatArrayOf(366f, 136f, 368f, 112f, 26f, 28f),
    val petals: Boolean = true,
    // v2.46: "cover" art fills the whole screen (cropped waist-up photo); hairZones = [cx, cy, rx, ry] ellipses of hair that swings
    val cover: Boolean = false,
    val hairZones: FloatArray? = null,
    val thumb: String = "yasmin_thumb1"
)

object Characters {
    private const val PREF = "character_idx"

    val all: List<CharProfile> = listOf(
        // the only character: the classic pink cat-ear Yasmin (all defaults). v2.44: the other five were removed.
        CharProfile(id = "classic", label = "Yasmin Classic", res = "yasmin_character", mask = "yasmin_bg_mask"),
        // v2.46: two new models, waist-up crops (768 x 1634) that fill the phone screen
        CharProfile(id = "blazer", label = "Yasmin Blazer", res = "yasmin_model2", thumb = "yasmin_thumb2",
            eLx = 324f, eLy = 614f, eRx = 450f, eRy = 592f, mx = 397f, my = 692f,
            lidW = 31f, lidH = 18f, lidTiltL = 5f, lidTiltR = -10f,
            skinTop = 0xFFF8E2D2, skinBot = 0xFFF3D2C2, skinMouth = 0xFFF2D6C8, lash = 0xFF4A2E2E,
            fs = 2.0f, patchW = 0.72f, patchH = 0.85f, mouthRot = -9f,
            cx = 384f, pivotY = 1634f, swayTop = 760f, breathBot = 1500f, breathTop = 560f, chestY = 1000f, chestW = 260f,
            headBot = 900f, headTop = 450f, hairByColor = false,
            hY0 = 0f, hY1 = 1f, hY2 = 5000f, hY3 = 5100f, lA = -5000f, lB = -5100f, rA = 5000f, rB = 5100f, rC = 6000f, rD = 6100f,
            earL = null, earR = null, ahoge = null, petals = false, cover = true,
            hairZones = floatArrayOf(120f, 980f, 120f, 330f, 650f, 980f, 110f, 330f)),
        CharProfile(id = "street", label = "Yasmin Street", res = "yasmin_model3", thumb = "yasmin_thumb3",
            eLx = 317f, eLy = 606f, eRx = 449f, eRy = 589f, mx = 395f, my = 684f,
            lidW = 34f, lidH = 19f, lidTiltL = 2f, lidTiltR = -10f,
            skinTop = 0xFFF8E0D0, skinBot = 0xFFF1CFBF, skinMouth = 0xFFF3D8CA, lash = 0xFF43302E,
            fs = 2.0f, patchW = 0.72f, patchH = 0.85f, mouthRot = -10f,
            cx = 384f, pivotY = 1634f, swayTop = 760f, breathBot = 1500f, breathTop = 560f, chestY = 1000f, chestW = 260f,
            headBot = 900f, headTop = 450f, hairByColor = false,
            hY0 = 0f, hY1 = 1f, hY2 = 5000f, hY3 = 5100f, lA = -5000f, lB = -5100f, rA = 5000f, rB = 5100f, rC = 6000f, rD = 6100f,
            earL = null, earR = null, ahoge = null, petals = true, cover = true,
            hairZones = floatArrayOf(110f, 1000f, 120f, 340f, 660f, 1000f, 120f, 340f))
    )

    // the models, in the order of the "Yasmin Model" page
    val thumbs: List<String> get() = all.map { it.thumb }

    fun saved(ctx: Context): Int = Prefs.getInt(ctx, PREF, 0).coerceIn(0, all.size - 1)
    fun save(ctx: Context, i: Int) = Prefs.putInt(ctx, PREF, i)
}
