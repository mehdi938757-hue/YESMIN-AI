# In-app update (v2.60) - how to publish an update

Users get a notification "Yasmin update available" with a Download button, see the new version, the release notes and the
download link in **menu > Update**, the app downloads the APK itself and opens the Android installer.
Nothing runs on your side: the app reads the **latest GitHub Release** of your repository.

## One-time setup
1. Open `app/src/main/java/ai/yasmin/assistant/Updater.kt` and set
   `const val UPDATE_REPO = "your-github-username/your-repo-name"`.
2. The repository must be **public** (a private repo answers 404 to the app, which has no token).
3. Build and install this version (2.60) once by hand. Every later version can update itself.

## Every time you publish an update
1. In `app/build.gradle.kts` raise **both** numbers, e.g. `versionCode = 61` and `versionName = "2.61"`.
2. Build the APK (Termux `build-termux.sh` or your usual way).
3. On GitHub: **Releases > Draft a new release**
   - Tag: `v2.61` (must match `versionName`, a leading `v` is fine)
   - Description: what is new (shown to the user in the app and in the notification)
   - Attach the **APK file** (any name ending in `.apk`)
   - **Publish release** (not "Save draft", not "pre-release": those are ignored)
4. Phones notice it within about 6 hours (or at once when the user opens the app / presses *Check for update*).

## Important: always sign with the SAME key
Android installs an update only when the new APK is signed with the same key as the installed one, otherwise it refuses
("App not installed"). `build-termux.sh` makes a *debug* APK signed with the debug key of the phone where you build:
build every release on the **same phone** and do not delete `~/.android/debug.keystore` (back it up). A build from GitHub
Actions uses a different key and will NOT install over a Termux-built version (users would have to uninstall first).

## What the app checks before installing
- the downloaded file is a real APK of the package `ai.yasmin.assistant`
- its versionCode is higher than the installed one
- the download size matches
Android itself then shows its normal install screen; the first time the user must allow "Install unknown apps" for Yasmin.

## Notes
- Update check needs no license key, so a locked phone can still be updated.
- One notification per version; the Download button starts the download, a second notification "tap to install" appears when
  it is finished (Android 10+ does not allow opening the installer from the background).
- GitHub allows 60 anonymous API calls per hour per IP address; the app asks at most once every 6 hours.
