package ai.yasmin.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import org.json.JSONObject

/** v2.58: flashlight, and Wi-Fi / mobile data / Bluetooth on or off. */
object PhoneToggles {
    private fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg)

    /** Flashlight: no root needed. */
    fun torch(ctx: Context, on: Boolean): JSONObject {
        val cm = ctx.getSystemService(CameraManager::class.java) ?: return fail("Camera service not available.")
        return try {
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                ?: return fail("This phone has no flashlight.")
            cm.setTorchMode(id, on)
            JSONObject().put("ok", true).put("verified", true).put("flashlight", if (on) "on" else "off")
        } catch (_: CameraAccessException) {
            fail("The flashlight could not be changed. The camera may be in use by another app.")
        } catch (e: Exception) {
            fail("Flashlight error: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** what = wifi | data | bluetooth. Root: svc command, checked afterwards. No root: opens quick settings and taps the tile. */
    fun connection(acc: YasminAccessibilityService?, what: String, on: Boolean): JSONObject {
        val key = what.lowercase().trim()
        if (key !in setOf("wifi", "data", "bluetooth")) return fail("Unknown connection \"$what\". Use wifi, data or bluetooth.")
        if (Root.available(false)) {
            val state = if (on) "enable" else "disable"
            val cmd = when (key) { "wifi" -> "svc wifi $state"; "data" -> "svc data $state"; else -> "svc bluetooth $state" }
            val (code, _) = Root.exec(cmd, 8000)
            if (code != 0) return fail("The root command for $key failed.")
            Thread.sleep(800)
            val out = when (key) {
                "wifi" -> Root.exec("cmd wifi status", 5000).second
                "data" -> Root.exec("settings get global mobile_data", 5000).second
                else -> Root.exec("settings get global bluetooth_on", 5000).second
            }
            val isOn = if (key == "wifi") out.contains("Wifi is enabled") else out.trim() == "1"
            val ok = isOn == on
            val r = JSONObject().put("ok", ok).put("verified", true).put("via", "root").put("what", key).put("state", if (isOn) "on" else "off")
            if (!ok) r.put("error", "The phone did not change $key. Try again or check it on screen.")
            return r
        }
        if (acc == null) return fail("Turn on Yasmin in Accessibility settings, or give root, and I can change $key.")
        acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        Thread.sleep(900)
        val labels = when (key) {
            "wifi" -> listOf("Wi-Fi", "Wifi")
            "data" -> listOf("Mobile data", "Mobile Data")
            else -> listOf("Bluetooth")
        }
        val tapped = labels.any { acc.clickText(it) }
        Thread.sleep(400)
        acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)   // close the panel again
        return if (tapped) {
            JSONObject().put("ok", true).put("verified", false).put("via", "screen").put("what", key)
                .put("note", "I tapped the $key tile. It is a toggle, so check on screen that it is in the state he asked for.")
        } else {
            fail("Could not find the $key tile in quick settings. Your phone may show it under another name.")
        }
    }
}
