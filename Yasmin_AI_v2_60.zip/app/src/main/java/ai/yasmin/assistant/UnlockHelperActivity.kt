package ai.yasmin.assistant

import android.app.Activity
import android.app.KeyguardManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager

/**
 * v2.48.2: a see-through screen whose only job is to ask Android to show the real PIN / pattern / password screen
 * (KeyguardManager.requestDismissKeyguard). This is more reliable than a swipe, which on phones with a lock-screen
 * "magazine" / news feed scrolls the feed instead of opening the lock. It never enters the lock itself.
 */
class UnlockHelperActivity : Activity() {
    companion object {
        @Volatile var current: UnlockHelperActivity? = null
        fun close() { val a = current ?: return; Handler(Looper.getMainLooper()).post { try { a.finish() } catch (_: Throwable) {} } }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        current = this
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else @Suppress("DEPRECATION") window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        try {
            getSystemService(KeyguardManager::class.java).requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() { finish() }
                override fun onDismissError() { finish() }
                // onDismissCancelled: the bouncer was closed, nothing more to do here
                override fun onDismissCancelled() { finish() }
            })
        } catch (_: Throwable) { finish() }
        Handler(Looper.getMainLooper()).postDelayed({ if (!isFinishing) finish() }, 20_000L)   // safety: never stays
    }

    override fun onDestroy() { if (current === this) current = null; super.onDestroy() }
}
