package ai.yasmin.assistant

import android.content.Context
import android.content.Intent

/**
 * v2.44: Personalization. The user can give the AI a name of their own and tell it their own name.
 *
 * - AI name: stored in [AI_KEY]. Empty = the default ([DEFAULT_AI]).
 * - Your name: stored in [Prefs.NAME] (the same key the old "Your name" box used). Empty = the default ([DEFAULT_USER]).
 *
 * Both names are letters and spaces only (any language). The wake words ("Hey Yasmin", "Sleep Yasmin") do NOT change: the offline
 * wake model is trained on them. The developer line ("Mehdi developed ...") does not change either.
 * The current names are cached here, so texts can be localized from anywhere without a Context.
 */
object Personalization {
    const val DEFAULT_AI = "Yasmin"
    const val DEFAULT_USER = "Mehdi"
    const val AI_KEY = "ai_name"
    const val MAX_LEN = 24

    @Volatile var ai: String = DEFAULT_AI
        private set
    @Volatile var user: String = DEFAULT_USER
        private set

    private val VALID = Regex("^[\\p{L}\\p{M}]+( [\\p{L}\\p{M}]+)*$")

    fun init(c: Context) {
        ai = Prefs.get(c, AI_KEY, "").trim().ifBlank { DEFAULT_AI }
        user = Prefs.get(c, Prefs.NAME, "").trim().let { if (it.isBlank() || it.equals("Raja", ignoreCase = true)) DEFAULT_USER else it }
    }

    fun aiName(c: Context): String { init(c); return ai }
    fun userName(c: Context): String { init(c); return user }
    fun isAiCustom(c: Context): Boolean = aiName(c) != DEFAULT_AI
    fun isUserCustom(c: Context): Boolean = userName(c) != DEFAULT_USER

    /** The cleaned name (spaces trimmed and collapsed), or null when it is not allowed: empty, too long, digits or symbols. */
    fun clean(raw: String): String? {
        val s = raw.trim().replace(Regex("\\s+"), " ")
        return if (s.isNotEmpty() && s.length <= MAX_LEN && VALID.matches(s)) s else null
    }

    /** What is wrong with [raw], in words for the person, or null when it is fine. */
    fun problem(raw: String): String? {
        val s = raw.trim()
        return when {
            s.isEmpty() -> "Type a name first."
            s.length > MAX_LEN -> "Keep it up to $MAX_LEN letters."
            clean(raw) == null -> "Letters and spaces only, no numbers or symbols."
            else -> null
        }
    }

    /** Saves the AI name ("" = back to the default). Returns false when the name is not allowed. */
    fun saveAi(c: Context, raw: String): Boolean {
        val v = if (raw.isBlank()) "" else (clean(raw) ?: return false)
        Prefs.put(c, AI_KEY, if (v == DEFAULT_AI) "" else v)
        changed(c); return true
    }

    /** Saves your name ("" = back to the default). Returns false when the name is not allowed. */
    fun saveUser(c: Context, raw: String): Boolean {
        val v = if (raw.isBlank()) "" else (clean(raw) ?: return false)
        Prefs.put(c, Prefs.NAME, if (v == DEFAULT_USER) "" else v)
        changed(c); return true
    }

    /** Reloads the cache; a running voice session reconnects (memory is kept) so the new names work at once. */
    private fun changed(c: Context) {
        init(c)
        if (AppState.running.value)
            c.startService(Intent(c, AssistantService::class.java).setAction(AssistantService.ACTION_PERSONA))
    }

    // ---------------------------------------------------------------- putting the names into the fixed texts and prompts

    private const val KEEP = "\u0001"
    private const val DEV = "\u0002"

    /** Swaps the default names in [text] for the current ones. Same text back when both names are default. */
    fun localize(text: String): String {
        val a = ai; val u = user
        if (a == DEFAULT_AI && u == DEFAULT_USER) return text
        return text.split('\n').joinToString("\n") { line -> localizeLine(line, a, u) }
    }

    private fun localizeLine(line: String, a: String, u: String): String {
        var s = line
        if (a != DEFAULT_AI) {
            s = s.replace("Hey $DEFAULT_AI", "Hey $KEEP").replace("Sleep $DEFAULT_AI", "Sleep $KEEP")   // wake words stay
            s = s.replace(DEFAULT_AI, a).replace(KEEP, DEFAULT_AI)
        }
        if (u != DEFAULT_USER && !s.startsWith("WHO MADE YOU")) {
            s = s.replace("$DEFAULT_USER developed", "$DEV developed")                                    // the developer stays
            s = s.replace(" (say it clearly, like MEH-dee)", "")
            s = s.replace("\u09ae\u09c7\u09b9\u09c7\u09a6\u09c0\u09b0", "$u-\u098f\u09b0")                 // Bengali "of Mehdi"
            s = s.replace("\u09ae\u09c7\u09b9\u09c7\u09a6\u09c0", u).replace("\u092e\u0947\u0939\u0926\u0940", u)
            s = s.replace(DEFAULT_USER, u).replace(DEV, DEFAULT_USER)
        }
        return s
    }
}
