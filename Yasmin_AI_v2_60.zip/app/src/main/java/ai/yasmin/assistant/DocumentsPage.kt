package ai.yasmin.assistant

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

/** v2.57: the Documents section. Lists the research documents Yasmin saved and opens them. */
@Composable
fun DocumentsPage() {
    val ctx = LocalContext.current
    var version by remember { mutableStateOf(0) }
    val files = remember(version) { DeepResearch.list(ctx) }
    var open by remember { mutableStateOf<File?>(null) }
    val doc = open
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (doc == null) {
            Text("Documents", color = YasminUi.Text, fontSize = 22.sp)
            Text("Yasmin saves her research here: " + DeepResearch.folder(ctx).absolutePath, color = YasminUi.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Text("Refresh", color = YasminUi.Cyan, fontSize = 14.sp, modifier = Modifier.clickable { version++ })
            Spacer(Modifier.height(10.dp))
            if (files.isEmpty()) Text("No documents yet. Ask Yasmin to research something.", color = YasminUi.Muted, fontSize = 14.sp)
            files.forEach { f ->
                Text(f.nameWithoutExtension, color = YasminUi.Text, fontSize = 15.sp,
                    modifier = Modifier.fillMaxWidth().clickable { open = f }.padding(vertical = 10.dp))
            }
        } else {
            val body = remember(doc) { runCatching { doc.readText() }.getOrElse { "Could not read the file: ${it.message}" } }
            Text("< Back", color = YasminUi.Cyan, fontSize = 15.sp, modifier = Modifier.clickable { open = null }.padding(bottom = 8.dp))
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                Text(body, color = YasminUi.Text, fontSize = 14.sp)
            }
        }
    }
}
