package ai.yasmin.assistant

import android.content.Context
import android.content.Intent

/*
 * v2.47, Language Lock.
 *
 *   AUTO (default): Yasmin answers in whatever language the person speaks, any language of the world, and switches by herself when the
 *                   person changes to another language in a full sentence.
 *   LOCK:           the user picks one language; Yasmin understands everything but speaks / writes only that language.
 *
 * The choice becomes one block at the END of her voice prompt (it overrides the older "Bengali, Hindi and English only" lines), and
 * the auto-reply writer uses [autoReplyInstruction] so a WhatsApp / Messenger contact who writes Tamil, Arabic, French ... gets the
 * same language back.
 */
class Lang(val code: String, val name: String, val native: String, val group: String)

object LanguageLock {
    const val INDIA = "Indian languages"
    const val NEIGHBOURS = "Neighbouring countries"
    const val WORLD = "World languages"

    private const val MODE = "lang_mode"        // "auto" | "lock"
    private const val CODE = "lang_locked"

    val all: List<Lang> = listOf(
        // ---- India (the 22 scheduled languages first, then widely spoken ones)
        Lang("hi", "Hindi", "हिन्दी", INDIA), Lang("hinglish", "Hinglish (Hindi in English letters)", "Hinglish", INDIA),
        Lang("en-in", "English (Indian)", "English", INDIA), Lang("bn", "Bengali", "বাংলা", INDIA),
        Lang("te", "Telugu", "తెలుగు", INDIA), Lang("mr", "Marathi", "मराठी", INDIA), Lang("ta", "Tamil", "தமிழ்", INDIA),
        Lang("ur", "Urdu", "اردو", INDIA), Lang("gu", "Gujarati", "ગુજરાતી", INDIA), Lang("kn", "Kannada", "ಕನ್ನಡ", INDIA),
        Lang("or", "Odia", "ଓଡ଼ିଆ", INDIA), Lang("ml", "Malayalam", "മലയാളം", INDIA), Lang("pa", "Punjabi", "ਪੰਜਾਬੀ", INDIA),
        Lang("as", "Assamese", "অসমীয়া", INDIA), Lang("mai", "Maithili", "मैथिली", INDIA), Lang("sat", "Santali", "ᱥᱟᱱᱛᱟᱲᱤ", INDIA),
        Lang("ks", "Kashmiri", "کٲشُر", INDIA), Lang("ne", "Nepali", "नेपाली", INDIA), Lang("sd", "Sindhi", "سنڌي", INDIA),
        Lang("kok", "Konkani", "कोंकणी", INDIA), Lang("doi", "Dogri", "डोगरी", INDIA), Lang("mni", "Manipuri (Meitei)", "ꯃꯦꯇꯦꯏ", INDIA),
        Lang("brx", "Bodo", "बड़ो", INDIA), Lang("sa", "Sanskrit", "संस्कृतम्", INDIA),
        Lang("bho", "Bhojpuri", "भोजपुरी", INDIA), Lang("raj", "Rajasthani (Marwari)", "राजस्थानी", INDIA), Lang("hne", "Chhattisgarhi", "छत्तीसगढ़ी", INDIA),
        Lang("bgc", "Haryanvi", "हरयाणवी", INDIA), Lang("mag", "Magahi", "मगही", INDIA), Lang("awa", "Awadhi", "अवधी", INDIA),
        Lang("tcy", "Tulu", "ತುಳು", INDIA), Lang("kha", "Khasi", "Khasi", INDIA), Lang("lus", "Mizo", "Mizo", INDIA),
        // ---- countries around India
        Lang("bn-bd", "Bengali (Bangladesh)", "বাংলা (বাংলাদেশ)", NEIGHBOURS), Lang("ur-pk", "Urdu (Pakistan)", "اردو (پاکستان)", NEIGHBOURS),
        Lang("ps", "Pashto", "پښتو", NEIGHBOURS), Lang("fa-af", "Dari (Afghanistan)", "دری", NEIGHBOURS), Lang("bal", "Balochi", "بلوچی", NEIGHBOURS),
        Lang("si", "Sinhala (Sri Lanka)", "සිංහල", NEIGHBOURS), Lang("ta-lk", "Tamil (Sri Lanka)", "தமிழ் (இலங்கை)", NEIGHBOURS),
        Lang("dz", "Dzongkha (Bhutan)", "རྫོང་ཁ", NEIGHBOURS), Lang("dv", "Dhivehi (Maldives)", "ދިވެހި", NEIGHBOURS),
        Lang("my", "Burmese (Myanmar)", "မြန်မာ", NEIGHBOURS), Lang("bo", "Tibetan", "བོད་སྐད", NEIGHBOURS),
        // ---- the rest of the world
        Lang("en", "English", "English", WORLD), Lang("ar", "Arabic", "العربية", WORLD), Lang("zh", "Chinese (Mandarin)", "中文", WORLD),
        Lang("yue", "Cantonese", "粵語", WORLD), Lang("ja", "Japanese", "日本語", WORLD), Lang("ko", "Korean", "한국어", WORLD),
        Lang("fr", "French", "Français", WORLD), Lang("de", "German", "Deutsch", WORLD), Lang("es", "Spanish", "Español", WORLD),
        Lang("pt", "Portuguese", "Português", WORLD), Lang("ru", "Russian", "Русский", WORLD), Lang("it", "Italian", "Italiano", WORLD),
        Lang("tr", "Turkish", "Türkçe", WORLD), Lang("id", "Indonesian", "Bahasa Indonesia", WORLD), Lang("ms", "Malay", "Bahasa Melayu", WORLD),
        Lang("th", "Thai", "ไทย", WORLD), Lang("vi", "Vietnamese", "Tiếng Việt", WORLD), Lang("fil", "Filipino (Tagalog)", "Filipino", WORLD),
        Lang("fa", "Persian (Farsi)", "فارسی", WORLD), Lang("he", "Hebrew", "עברית", WORLD), Lang("nl", "Dutch", "Nederlands", WORLD),
        Lang("pl", "Polish", "Polski", WORLD), Lang("uk", "Ukrainian", "Українська", WORLD), Lang("sv", "Swedish", "Svenska", WORLD),
        Lang("no", "Norwegian", "Norsk", WORLD), Lang("da", "Danish", "Dansk", WORLD), Lang("fi", "Finnish", "Suomi", WORLD),
        Lang("el", "Greek", "Ελληνικά", WORLD), Lang("cs", "Czech", "Čeština", WORLD), Lang("sk", "Slovak", "Slovenčina", WORLD),
        Lang("ro", "Romanian", "Română", WORLD), Lang("hu", "Hungarian", "Magyar", WORLD), Lang("bg", "Bulgarian", "Български", WORLD),
        Lang("sr", "Serbian", "Српски", WORLD), Lang("hr", "Croatian", "Hrvatski", WORLD), Lang("sw", "Swahili", "Kiswahili", WORLD),
        Lang("am", "Amharic", "አማርኛ", WORLD), Lang("ha", "Hausa", "Hausa", WORLD), Lang("yo", "Yoruba", "Yorùbá", WORLD),
        Lang("zu", "Zulu", "isiZulu", WORLD), Lang("af", "Afrikaans", "Afrikaans", WORLD), Lang("km", "Khmer", "ខ្មែរ", WORLD),
        Lang("lo", "Lao", "ລາວ", WORLD), Lang("mn", "Mongolian", "Монгол", WORLD), Lang("ku", "Kurdish", "Kurdî", WORLD),
        Lang("uz", "Uzbek", "Oʻzbek", WORLD), Lang("kk", "Kazakh", "Қазақша", WORLD), Lang("az", "Azerbaijani", "Azərbaycan", WORLD),
        Lang("ka", "Georgian", "ქართული", WORLD), Lang("hy", "Armenian", "Հայերեն", WORLD)
    )

    fun find(code: String): Lang? = all.firstOrNull { it.code == code }

    fun lockedLang(c: Context): Lang? =
        if (Prefs.get(c, MODE, "auto") == "lock") find(Prefs.get(c, CODE, "")) else null
    fun isLocked(c: Context): Boolean = lockedLang(c) != null
    /** The language chosen last (kept when the user goes back to automatic), or null. */
    fun chosen(c: Context): Lang? = find(Prefs.get(c, CODE, ""))

    fun setAuto(c: Context) { Prefs.put(c, MODE, "auto"); changed(c) }
    fun lock(c: Context, code: String) {
        if (find(code) == null) return
        Prefs.put(c, CODE, code); Prefs.put(c, MODE, "lock"); changed(c)
    }

    /** A running voice session reconnects (memory is kept) so the new language works at once. */
    private fun changed(c: Context) {
        if (AppState.running.value)
            c.startService(Intent(c, AssistantService::class.java).setAction(AssistantService.ACTION_PERSONA))
    }

    // ------------------------------------------------------------------ the prompt block (appended LAST, so it wins over older language lines)

    fun promptNote(c: Context): String {
        val user = Personalization.userName(c)
        val ai = Personalization.aiName(c)
        val names = "NAMES: his name is $user and your own name is $ai. Say and write both naturally in the language you are speaking, in that language's own script, and always use his name when you talk to him."
        val l = lockedLang(c)
        return if (l == null)
            "\n\nLANGUAGE MODE: AUTOMATIC SWITCH (this overrides every earlier line about which languages you may use, about the list of allowed languages and about staying in one language). " +
                "You can speak every language of the world, including all Indian languages (Hindi, Bengali, Tamil, Telugu, Marathi, Gujarati, Kannada, Malayalam, Punjabi, Odia, Assamese, Urdu, Bhojpuri and the rest). " +
                "Answer in the language of his LAST full sentence, whatever it is. When he, or the person he is talking with, changes to another language in a full sentence, switch to that language at once and keep it until it changes again. " +
                "One word, a name, a song title, an app name or a noisy transcription never changes your language. Do not mix languages unless he mixes them first (Hinglish is fine when he speaks Hinglish). Your voice stays exactly the same in every language. $names"
        else
            "\n\nLANGUAGE MODE: LOCKED TO ${l.name.uppercase()} (${l.native}) (this overrides every earlier line about languages, including any line that says to follow the language he speaks). " +
                "Speak and write ONLY ${l.name} in every reply, greeting, heads-up, question, confirmation and error message, from the first word to the last" +
                (if (l.code == "hinglish") " (Hindi written in English letters, with simple English words mixed in)." else ".") +
                " You still understand every language he speaks, but you always answer in ${l.name}, even if he or someone else speaks another language. " +
                "Change language only if he clearly asks you to change it, and then tell him he can also change the lock in the menu under Language Lock. Your voice stays exactly the same. $names"
    }

    // ------------------------------------------------------------------ auto-reply (WhatsApp / Messenger): other scripts

    private val SCRIPTS: List<Triple<IntRange, String, String>> = listOf(
        Triple(0x0A00..0x0A7F, "Punjabi", "Gurmukhi"), Triple(0x0A80..0x0AFF, "Gujarati", "Gujarati"), Triple(0x0B00..0x0B7F, "Odia", "Odia"),
        Triple(0x0B80..0x0BFF, "Tamil", "Tamil"), Triple(0x0C00..0x0C7F, "Telugu", "Telugu"), Triple(0x0C80..0x0CFF, "Kannada", "Kannada"),
        Triple(0x0D00..0x0D7F, "Malayalam", "Malayalam"), Triple(0x0D80..0x0DFF, "Sinhala", "Sinhala"), Triple(0x0E00..0x0E7F, "Thai", "Thai"),
        Triple(0x0600..0x06FF, "Urdu, Arabic or Persian (use the one the sender is clearly writing)", "Arabic"), Triple(0x0590..0x05FF, "Hebrew", "Hebrew"),
        Triple(0x3040..0x30FF, "Japanese", "Japanese"), Triple(0x4E00..0x9FFF, "Chinese", "Chinese"), Triple(0xAC00..0xD7AF, "Korean", "Hangul"),
        Triple(0x0400..0x04FF, "Russian or another Cyrillic language (use the one the sender is clearly writing)", "Cyrillic"), Triple(0x0370..0x03FF, "Greek", "Greek"),
        Triple(0x10A0..0x10FF, "Georgian", "Georgian"), Triple(0x0530..0x058F, "Armenian", "Armenian"), Triple(0x1200..0x137F, "Amharic", "Ethiopic"),
        Triple(0x1000..0x109F, "Burmese", "Myanmar"), Triple(0x1780..0x17FF, "Khmer", "Khmer"), Triple(0x0F00..0x0FFF, "Tibetan", "Tibetan")
    )

    /** The language name of the dominant "other" script in [text], or null when it is Bengali / Devanagari / Latin / unclear. */
    fun otherScriptLanguage(text: String): String? {
        val counts = IntArray(SCRIPTS.size)
        var bnDev = 0
        for (ch in text) {
            val cp = ch.code
            if (cp in 0x0900..0x09FF) { bnDev++; continue }
            for (i in SCRIPTS.indices) if (cp in SCRIPTS[i].first) { counts[i]++; break }
        }
        var best = -1
        for (i in counts.indices) if (counts[i] >= 2 && counts[i] >= bnDev && (best < 0 || counts[i] > counts[best])) best = i
        return if (best < 0) null else SCRIPTS[best].second
    }

    /** [base] is BrainLanguage's own instruction line; a sender who writes another script or language gets his own language back. */
    fun autoReplyInstruction(text: String, base: String): String {
        val other = otherScriptLanguage(text)
        if (other != null)
            return "LANGUAGE (decided by the Main Brain, follow it): the sender wrote in $other. Understand it and reply in the same language and the same script, naturally."
        return base + " If the sender clearly writes in some other language than the one named here (for example French, Spanish, Tamil in English letters), reply in the sender's language instead."
    }
}
