package ai.yasmin.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * v2.60: In-app update through GitHub Releases.
 *
 * The owner publishes a GitHub Release (tag like `v2.60`) and attaches the signed APK to it. The app asks
 * `https://api.github.com/repos/<UPDATE_REPO>/releases/latest` (no server of your own is needed), compares the tag with its own
 * versionName, and when the release is newer it:
 *   1. shows a notification ("Update available") with a Download button,
 *   2. shows the version, the release notes and the download link in menu > Update,
 *   3. downloads the APK itself (progress bar), checks it is really this app and really newer,
 *   4. opens the Android installer (the user taps Install).
 *
 * It does NOT need the license key, so a locked phone can still be updated.
 * Needs: a PUBLIC repo (a private repo answers 404 without a token), and the APK of every release signed with the SAME key,
 * otherwise Android refuses to install it over the old one. See UPDATE-SETUP.md.
 */
object Updater {
    /** >>> SET THIS ONCE: "github-username/repository-name" of the repo where you publish the releases. <<< */
    const val UPDATE_REPO = "YOUR_GITHUB_USERNAME/YOUR_REPO"

    const val ACTION_DOWNLOAD = "ai.yasmin.update.DOWNLOAD"
    const val EXTRA_OPEN_UPDATE = "open_update"
    const val EXTRA_INSTALL = "open_update_install"

    private const val CHANNEL = "yasmin_update"
    private const val NOTIF_ID = 59
    private const val NOTIF_READY_ID = 60
    private const val K_LAST_CHECK = "upd_last_check"
    private const val K_NOTIFIED = "upd_notified_tag"
    private const val K_SKIP = "upd_skip_tag"
    private const val CHECK_EVERY_MS = 6L * 60 * 60 * 1000      // background check every 6 hours (GitHub allows 60 anonymous calls per hour)

    data class Info(val tag: String, val version: String, val notes: String, val apkUrl: String, val apkName: String, val apkSize: Long, val pageUrl: String)

    sealed class Dl {
        object Idle : Dl()
        data class Running(val percent: Int, val bytes: Long, val total: Long) : Dl()
        data class Ready(val file: File) : Dl()
        data class Failed(val message: String) : Dl()
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _available = MutableStateFlow<Info?>(null)
    /** The newer release, or null when the app is up to date / not checked yet. */
    val available: StateFlow<Info?> = _available
    private val _checking = MutableStateFlow(false)
    val checking: StateFlow<Boolean> = _checking
    private val _status = MutableStateFlow("")
    /** Short text for the Update page: "You have the latest version", "No internet", ... */
    val status: StateFlow<String> = _status
    private val _dl = MutableStateFlow<Dl>(Dl.Idle)
    val download: StateFlow<Dl> = _dl
    @Volatile private var started = false

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).followRedirects(true).build()
    }

    fun repoConfigured() = !UPDATE_REPO.startsWith("YOUR_") && UPDATE_REPO.contains("/")

    fun currentVersion(ctx: Context): String = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }

    /** Called once from Application.onCreate: checks now (when the last check is old) and then every 6 hours while the process lives. */
    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        scope.launch {
            delay(8000)   // let the app finish starting first
            while (true) {
                val last = Prefs.get(app, K_LAST_CHECK, "0").toLongOrNull() ?: 0L
                if (System.currentTimeMillis() - last !in 0..CHECK_EVERY_MS) checkNow(app, manual = false)
                delay(30L * 60 * 1000)   // look again in 30 min whether the 6 h are over (cheap, no network when not due)
            }
        }
    }

    /** Called when the app comes to the front: checks again only when the last check is more than an hour old. */
    fun checkIfDue(ctx: Context) {
        val last = Prefs.get(ctx, K_LAST_CHECK, "0").toLongOrNull() ?: 0L
        if (System.currentTimeMillis() - last !in 0..60L * 60 * 1000) check(ctx, manual = false)
    }

    /** Asks GitHub for the latest release. [manual] = the user pressed "Check for update": always answers with a status text. */
    fun check(ctx: Context, manual: Boolean = true) {
        val app = ctx.applicationContext
        scope.launch { checkNow(app, manual) }
    }

    private fun checkNow(app: Context, manual: Boolean) {
        if (_checking.value) return
        if (!repoConfigured()) { if (manual) _status.value = "Update source is not set yet (UPDATE_REPO in Updater.kt)."; return }
        _checking.value = true
        if (manual) _status.value = "Checking..."
        try {
            val req = Request.Builder().url("https://api.github.com/repos/$UPDATE_REPO/releases/latest")
                .header("Accept", "application/vnd.github+json").header("User-Agent", "YasminAI-Updater").build()
            http.newCall(req).execute().use { r ->
                when {
                    r.code == 404 -> { if (manual) _status.value = "No release found. The repository must be public and have a published Release."; return }
                    r.code == 403 || r.code == 429 -> { if (manual) _status.value = "GitHub is busy right now. Try again in a few minutes."; return }
                    !r.isSuccessful -> { if (manual) _status.value = "Update check failed (HTTP ${r.code})."; return }
                }
                val j = JSONObject(r.body?.string() ?: return)
                Prefs.put(app, K_LAST_CHECK, System.currentTimeMillis().toString())
                val tag = j.optString("tag_name")
                val ver = tag.trim().removePrefix("v").removePrefix("V")
                var apkUrl = ""; var apkName = ""; var apkSize = 0L
                val assets = j.optJSONArray("assets")
                if (assets != null) for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                        apkUrl = a.optString("browser_download_url"); apkName = a.optString("name"); apkSize = a.optLong("size"); break
                    }
                }
                val current = currentVersion(app)
                if (ver.isEmpty() || apkUrl.isEmpty()) { if (manual) _status.value = "The latest release has no APK file attached."; return }
                if (compare(ver, current) > 0) {
                    val info = Info(tag, ver, j.optString("body").trim(), apkUrl, apkName, apkSize, j.optString("html_url"))
                    _available.value = info
                    _status.value = "Update available: v$ver"
                    notifyOnce(app, info)
                } else {
                    _available.value = null
                    if (manual) _status.value = "You have the latest version (v$current)."
                }
            }
        } catch (e: Exception) {
            if (manual) _status.value = "No internet or GitHub not reachable."
        } finally { _checking.value = false }
    }

    /** Compares dotted numbers: "2.60" > "2.59", "2.10" > "2.9". Anything that is not a number counts as 0. */
    fun compare(a: String, b: String): Int {
        fun parts(s: String) = s.split('.', '-', '_').map { p -> p.takeWhile { it.isDigit() }.toIntOrNull() ?: 0 }
        val x = parts(a); val y = parts(b)
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = (x.getOrElse(i) { 0 }).compareTo(y.getOrElse(i) { 0 })
            if (d != 0) return d
        }
        return 0
    }

    // ---------------------------------------------------------------------------------------------------- notification

    private fun notifyOnce(app: Context, info: Info) {
        if (Prefs.get(app, K_NOTIFIED, "") == info.tag) return   // one notification per version
        if (Build.VERSION.SDK_INT >= 33 && app.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val nm = app.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Yasmin updates", NotificationManager.IMPORTANCE_DEFAULT))
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val open = PendingIntent.getActivity(app, 1, Intent(app, MainActivity::class.java).putExtra(EXTRA_OPEN_UPDATE, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), flags)
            val dl = PendingIntent.getBroadcast(app, 2, Intent(app, UpdateReceiver::class.java).setAction(ACTION_DOWNLOAD), flags)
            val text = "Version ${info.version} is ready. Tap to see what's new and download it."
            val n = NotificationCompat.Builder(app, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Yasmin update available")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text + (if (info.notes.isNotBlank()) "\n\n" + info.notes.take(300) else "")))
                .setContentIntent(open).setAutoCancel(true)
                .addAction(0, "Download", dl)
                .build()
            nm.notify(NOTIF_ID, n)
            Prefs.put(app, K_NOTIFIED, info.tag)
        } catch (_: Exception) {}
    }

    private fun notifyReady(app: Context, info: Info) {
        if (Build.VERSION.SDK_INT >= 33 && app.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val nm = app.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Yasmin updates", NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(app, 3, Intent(app, MainActivity::class.java).putExtra(EXTRA_OPEN_UPDATE, true).putExtra(EXTRA_INSTALL, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify(NOTIF_READY_ID, NotificationCompat.Builder(app, CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Yasmin ${info.version} downloaded").setContentText("Tap to install the update.")
                .setContentIntent(pi).setAutoCancel(true).build())
        } catch (_: Exception) {}
    }

    fun cancelNotification(ctx: Context) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.cancel(NOTIF_READY_ID)
            nm.cancel(NOTIF_ID)
        } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------------------------------------------- download

    private fun apkFile(ctx: Context) = File(File(ctx.cacheDir, "updates").also { it.mkdirs() }, "yasmin-update.apk")

    /** Downloads the APK of [available] (progress in [download]); when done it is verified and, with [autoInstall], the installer opens. */
    fun startDownload(ctx: Context, autoInstall: Boolean = true) {
        val app = ctx.applicationContext
        val info = _available.value ?: return
        if (_dl.value is Dl.Running) return
        _dl.value = Dl.Running(0, 0, info.apkSize)
        scope.launch {
            val out = apkFile(app)
            try {
                out.delete()
                val req = Request.Builder().url(info.apkUrl).header("User-Agent", "YasminAI-Updater").build()
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) { _dl.value = Dl.Failed("Download failed (HTTP ${r.code})."); return@launch }
                    val body = r.body ?: run { _dl.value = Dl.Failed("Empty download."); return@launch }
                    val total = if (body.contentLength() > 0) body.contentLength() else info.apkSize
                    var done = 0L; var lastPct = -1
                    body.byteStream().use { input ->
                        out.outputStream().use { o ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = input.read(buf); if (n < 0) break
                                o.write(buf, 0, n); done += n
                                val pct = if (total > 0) (done * 100 / total).toInt().coerceIn(0, 100) else 0
                                if (pct != lastPct) { lastPct = pct; _dl.value = Dl.Running(pct, done, total) }
                            }
                        }
                    }
                    if (total > 0 && done != total) { out.delete(); _dl.value = Dl.Failed("The download was cut off. Try again."); return@launch }
                }
                val problem = verify(app, out)
                if (problem != null) { out.delete(); _dl.value = Dl.Failed(problem); return@launch }
                _dl.value = Dl.Ready(out)
                notifyReady(app, info)   // Android 10+ blocks opening the installer from the background, so a tap on this notification does it
                if (autoInstall) install(app)
            } catch (e: Exception) {
                out.delete()
                _dl.value = Dl.Failed("Download failed: no internet or the connection broke.")
            }
        }
    }

    /** The file must be an Android package with OUR package name and a higher versionCode than the installed one. Returns an error text or null. */
    private fun verify(ctx: Context, f: File): String? {
        val pi = try { ctx.packageManager.getPackageArchiveInfo(f.absolutePath, 0) } catch (_: Exception) { null }
            ?: return "The downloaded file is not a valid APK."
        if (pi.packageName != ctx.packageName) return "The downloaded APK is a different app. Update cancelled."
        val cur = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0) } catch (_: Exception) { return null }
        val newCode = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
        val curCode = if (Build.VERSION.SDK_INT >= 28) cur.longVersionCode else @Suppress("DEPRECATION") cur.versionCode.toLong()
        if (newCode <= curCode) return "The APK in the release is not newer (versionCode $newCode, installed $curCode)."
        return null
    }

    // ---------------------------------------------------------------------------------------------------- install

    /** Opens the Android installer for the downloaded APK. The first time, Android asks to allow "install unknown apps" for Yasmin. */
    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val f = (_dl.value as? Dl.Ready)?.file ?: apkFile(app).takeIf { it.exists() } ?: return
        if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) {
            _status.value = "Allow \"Install unknown apps\" for Yasmin, come back and tap Install again."
            app.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${app.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        try {
            val uri = FileProvider.getUriForFile(app, app.packageName + ".updates", f)
            app.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            _dl.value = Dl.Failed("The installer could not be opened: " + (e.message ?: ""))
        }
    }

    /** Opens the release APK link in the browser (fallback / "download link"). */
    fun openLink(ctx: Context, url: String) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    /** After the new version started: the old APK is no longer needed. */
    fun cleanupAfterUpdate(ctx: Context) {
        try { File(ctx.cacheDir, "updates").deleteRecursively() } catch (_: Exception) {}
        cancelNotification(ctx)
        Prefs.put(ctx, K_NOTIFIED, "")
    }
}

/** Handles the "Download" button of the update notification. */
class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Updater.ACTION_DOWNLOAD) return
        Updater.cancelNotification(c)
        if (Updater.available.value == null) {
            // process was restarted since the notification: bring the Update page up, it checks again by itself
            c.startActivity(Intent(c, MainActivity::class.java).putExtra(Updater.EXTRA_OPEN_UPDATE, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else Updater.startDownload(c)
    }
}
