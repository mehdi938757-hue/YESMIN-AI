package ai.yasmin.assistant

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.MessageDigest

/**
 * v2.49: License key checked against the Firebase Realtime Database.
 *
 * Database layout (see LICENSE-SETUP.md):   licenses / <KEY> / { active: true, expiresAt: 0 (ms since 1970, 0 = never) }   (the phone writes `deviceId` itself)
 *
 * Activation: the key must exist, be active and not expired. The first phone that activates it writes its own id into `deviceId`
 * (an atomic transaction, so two phones can never both win); any other phone is refused. The result is remembered on the phone,
 * and checked again online about every 12 hours. Without internet a verified phone keeps working for 7 days (grace), so a short
 * offline spell never locks anyone out, but a switched-off or moved key is noticed on the next online check.
 *
 * Everything else in the app asks only [isUnlocked] (fast, no network).
 * v2.51: WITHOUT a valid key the whole app is locked: no assistant, no background service, no boot start, no custom lock, no pages.
 * Only the activation banner on Home and the License page work.
 */
object License {
    val FREE_TOOLS: Set<String> = setOf("set_emotion", "set_mode", "go_to_sleep")
    const val LOCKED_MESSAGE = "This needs the license key. Enter it in the menu under License."

    private const val K_KEY = "lic_key"
    private const val K_AT = "lic_verified_at"
    private const val RECHECK_MS = 12L * 60 * 60 * 1000
    private const val GRACE_MS = 7L * 24 * 60 * 60 * 1000
    private const val RETRY_MS = 5L * 60 * 1000

    private val _state = MutableStateFlow(false)
    /** Live "unlocked" flag for the UI. */
    val state: StateFlow<Boolean> = _state
    @Volatile private var checking = false
    @Volatile private var lastTry = 0L

    private fun now() = System.currentTimeMillis()

    /** Fast local answer. Also starts a background re-check when the last one is old. Safe to call from anywhere, any thread. */
    fun isUnlocked(ctx: Context): Boolean {
        val app = ctx.applicationContext
        val key = Prefs.get(app, K_KEY, "")
        if (key.isEmpty()) { _state.value = false; return false }
        val at = Prefs.get(app, K_AT, "0").toLongOrNull() ?: 0L
        val age = now() - at
        val valid = at > 0 && age in 0..GRACE_MS      // a clock set back makes age negative: counts as unverified until the next online check
        _state.value = valid
        if (age !in 0..RECHECK_MS) recheck(app)
        return valid
    }

    /** The saved key, last 4 characters only (for the page). */
    fun maskedKey(ctx: Context): String {
        val k = Prefs.get(ctx.applicationContext, K_KEY, "")
        return if (k.isEmpty()) "" else "•••• " + k.takeLast(4)
    }

    /** Removes the key from THIS phone. (The key stays tied to this phone in the database until the owner clears `deviceId` there.) */
    fun remove(ctx: Context) {
        val app = ctx.applicationContext
        Prefs.put(app, K_KEY, ""); Prefs.put(app, K_AT, "0"); _state.value = false
        lockAll(app)
    }

    /** The license is gone: stop everything that is running (the user's on/off choices stay, they just cannot run). */
    private fun lockAll(app: Context) {
        try { app.stopService(Intent(app, AssistantService::class.java)) } catch (_: Throwable) {}
        try { app.stopService(Intent(app, YasminBackgroundService::class.java)) } catch (_: Throwable) {}
    }

    private fun normalize(raw: String): String? {
        val k = raw.trim().uppercase().replace(" ", "")
        return if (Regex("^[A-Z0-9-]{6,64}$").matches(k)) k else null   // no . $ # [ ] / : they are not allowed in database paths
    }

    private fun deviceId(app: Context): String {
        val id = Settings.Secure.getString(app.contentResolver, Settings.Secure.ANDROID_ID).orEmpty().ifEmpty { "unknown" }
        return MessageDigest.getInstance("SHA-256").digest(("yasmin:$id").toByteArray()).joinToString("") { "%02x".format(it) }.take(32)
    }

    private fun licenses(): DatabaseReference = FirebaseDatabase.getInstance().getReference("licenses")

    /** null = the key is usable, otherwise what is wrong (in words for the person). */
    private fun problem(s: DataSnapshot): String? {
        if (!s.exists()) return "This license key does not exist. Check it and try again."
        if (s.child("active").getValue(Boolean::class.java) != true) return "This license key is switched off."
        val exp = s.child("expiresAt").getValue(Long::class.java) ?: 0L
        if (exp > 0 && exp < now()) return "This license key has expired."
        return null
    }

    private fun netMessage(e: Exception?): String {
        val m = e?.message.orEmpty()
        return if (m.contains("permission", true)) "The database refused the request. Check the Firebase rules (LICENSE-SETUP.md)."
        else "Could not reach the license server. Check the internet and try again. ($m)".trim()
    }

    /** Ties the key to this phone, or confirms it is already this phone. [done] runs on the main thread. */
    private fun bind(ref: DatabaseReference, dev: String, done: (Boolean, String) -> Unit) {
        ref.child("deviceId").runTransaction(object : Transaction.Handler {
            override fun doTransaction(cur: MutableData): Transaction.Result {
                val v = cur.getValue(String::class.java)
                return when {
                    v.isNullOrEmpty() -> { cur.value = dev; Transaction.success(cur) }
                    v == dev -> Transaction.success(cur)
                    else -> Transaction.abort()
                }
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snap: DataSnapshot?) {
                when {
                    error != null && error.code == DatabaseError.PERMISSION_DENIED -> done(false, "This license key is already used on another phone.")
                    error != null -> done(false, netMessage(error.toException()))
                    !committed -> done(false, "This license key is already used on another phone.")
                    else -> done(true, "")
                }
            }
        }, false)
    }

    /** Checks the key online and, if it is good, saves it on this phone. [done] (ok, message) runs on the main thread. */
    fun activate(ctx: Context, raw: String, done: (Boolean, String) -> Unit) {
        val app = ctx.applicationContext
        val key = normalize(raw) ?: return done(false, "That does not look like a license key (letters, digits and dashes, 6 to 64 characters).")
        try {
            val ref = licenses().child(key)
            ref.get().addOnCompleteListener { t ->
                if (!t.isSuccessful) { done(false, netMessage(t.exception)); return@addOnCompleteListener }
                val bad = problem(t.result)
                if (bad != null) { done(false, bad); return@addOnCompleteListener }
                bind(ref, deviceId(app)) { ok, msg ->
                    if (ok) { Prefs.put(app, K_KEY, key); Prefs.put(app, K_AT, now().toString()); _state.value = true; done(true, "License activated. Everything is unlocked.") }
                    else done(false, msg)
                }
            }
        } catch (e: Throwable) {
            done(false, "Firebase is not set up in this build (is google-services.json inside the app folder?): ${e.message}")
        }
    }

    /** Background re-check of the saved key. No internet = nothing changes (the 7-day grace keeps running). */
    private fun recheck(app: Context) {
        val key = Prefs.get(app, K_KEY, "")
        if (key.isEmpty() || checking || now() - lastTry < RETRY_MS) return
        checking = true; lastTry = now()
        try {
            val ref = licenses().child(key)
            ref.get().addOnCompleteListener { t ->
                if (!t.isSuccessful) { checking = false; return@addOnCompleteListener }       // offline / server problem: keep the grace
                val s = t.result
                val dev = s.child("deviceId").getValue(String::class.java).orEmpty()
                val mine = deviceId(app)
                fun good() { Prefs.put(app, K_AT, now().toString()); _state.value = true; checking = false }
                fun revoke() { Prefs.put(app, K_AT, "0"); _state.value = false; checking = false; lockAll(app) }
                when {
                    problem(s) != null -> revoke()
                    dev.isNotEmpty() && dev != mine -> revoke()
                    dev.isEmpty() -> bind(ref, mine) { ok, _ -> if (ok) good() else revoke() }   // the owner cleared the phone id: tie it to this phone again
                    else -> good()
                }
            }
        } catch (_: Throwable) { checking = false }
    }
}
