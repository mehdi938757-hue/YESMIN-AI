#!/data/data/com.termux/files/usr/bin/bash
# YASMIN AI app builder - runs inside Termux.
# Usage: build-app.sh setup | build SLUG | status SLUG | errors SLUG | apk SLUG | list | dump SLUG | fromdl [NAME-HINT] | finddl
export PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
export HOME="${HOME:-/data/data/com.termux/files/home}"
export PATH="$PREFIX/bin:$PATH"
TOOLS="$HOME/yasmin-tools"
APPS="$HOME/yasmin-apps"
GRADLE_HOME="$HOME/gradle-8.9"
export JAVA_HOME="$PREFIX/lib/jvm/java-17-openjdk"
export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export GRADLE_OPTS="-Dorg.gradle.native=false -Xmx1g"
export PATH="$JAVA_HOME/bin:$PATH"
mkdir -p "$TOOLS" "$APPS"

cmd="${1:-}"
slug="${2:-}"
if [ "$cmd" != "fromdl" ] && [ -n "$slug" ] && ! [[ "$slug" =~ ^[a-z0-9]+$ ]]; then echo "bad project name"; exit 2; fi

wakelock()   { command -v termux-wake-lock   >/dev/null 2>&1 && termux-wake-lock   || true; }
wakeunlock() { command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock || true; }

do_setup() {
  ST="$TOOLS/setup.status"; LOG="$TOOLS/setup.log"
  echo RUNNING > "$ST"; : > "$LOG"
  wakelock
  (
    set -e
    export DEBIAN_FRONTEND=noninteractive
    pkg update -y || echo "(pkg update had a problem; continuing)"
    pkg install -y openjdk-17 aapt2 curl unzip tar
    [ -x "$PREFIX/bin/aapt2" ] || { echo "aapt2 was not installed"; exit 1; }
    [ -x "$JAVA_HOME/bin/java" ] || { echo "Java 17 was not installed"; exit 1; }
    mkdir -p "$ANDROID_HOME/licenses"
    printf '\n8933bad161af4178b1185d1a37fbf41ea5269c55\nd56f5187479451eabf01fb78af6dfcb131a6481e\n24333f8a63b6825ea9c5514f83c2829b004d1fee\n' > "$ANDROID_HOME/licenses/android-sdk-license"
    printf '\n84831b9409646a918e30573bab4c9c91346d8abd\n' > "$ANDROID_HOME/licenses/android-sdk-preview-license"
    if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
      rm -f "$HOME/gradle-8.9-bin.zip"
      curl -L --fail --retry 3 -o "$HOME/gradle-8.9-bin.zip" https://services.gradle.org/distributions/gradle-8.9-bin.zip
      unzip -q -o "$HOME/gradle-8.9-bin.zip" -d "$HOME"
      rm -f "$HOME/gradle-8.9-bin.zip"
    fi
    chmod +x "$GRADLE_HOME/bin/gradle"
    touch "$TOOLS/.ready"
  ) >> "$LOG" 2>&1
  rc=$?
  wakeunlock
  if [ $rc -eq 0 ]; then echo OK > "$ST"; else echo FAILED > "$ST"; fi
}


# ---- Gradle of the version a project asks for (gradle-wrapper.properties); falls back to 8.9
gradle_for() {
  v="$1"
  if ! [[ "$v" =~ ^[0-9]+(\.[0-9]+){1,2}$ ]] || [ "$(printf '%s\n7.3\n' "$v" | sort -V | head -n 1)" != "7.3" ]; then echo "$GRADLE_HOME"; return; fi
  H="$HOME/gradle-$v"
  if [ ! -x "$H/bin/gradle" ]; then
    rm -f "$HOME/gradle-$v-bin.zip"
    if curl -L --fail --retry 3 -o "$HOME/gradle-$v-bin.zip" "https://services.gradle.org/distributions/gradle-$v-bin.zip" >&2; then
      unzip -q -o "$HOME/gradle-$v-bin.zip" -d "$HOME" >&2
    fi
    rm -f "$HOME/gradle-$v-bin.zip"
    chmod +x "$H/bin/gradle" 2>/dev/null
  fi
  if [ -x "$H/bin/gradle" ]; then echo "$H"; else echo "$GRADLE_HOME"; fi
}

# ---- projects (zip files or folders with a settings.gradle) that lie in the Download / Documents folder of the phone
dl_roots() {
  for d in /sdcard/Download /storage/emulated/0/Download "$HOME/storage/downloads" /sdcard/Documents; do
    if [ -d "$d" ] && ls "$d" >/dev/null 2>&1; then readlink -f "$d"; fi
  done | sort -u
}

dl_candidates() {   # prints: mtime<TAB>path, newest first
  dl_roots | while IFS= read -r r; do
    [ -n "$r" ] || continue
    find "$r" -maxdepth 2 -type f -iname '*.zip' -printf '%T@\t%p\n' 2>/dev/null
    find "$r" -maxdepth 3 -type f \( -name settings.gradle -o -name settings.gradle.kts \) -printf '%T@\t%h\n' 2>/dev/null
  done | grep -v '/build/' | sort -rn -k1,1
}

is_project_src() {  # $1 = zip or folder
  if [ -d "$1" ]; then return 0; fi
  unzip -l "$1" 2>/dev/null | grep -qE '(^|[ /])settings\.gradle(\.kts)?$'
}

do_finddl() {
  if [ -z "$(dl_roots)" ]; then echo "ERR: NOSTORAGE"; return 3; fi
  n=0
  dl_candidates | while IFS=$'\t' read -r t path; do
    [ -n "$path" ] || continue
    if is_project_src "$path"; then echo "PROJECT: $(basename "$path")"; n=$((n+1)); [ "$n" -ge 12 ] && break; fi
  done
  return 0
}

do_fromdl() {
  hint="$(printf '%s' "${1:-}" | tr 'A-Z' 'a-z')"
  if [ -z "$(dl_roots)" ]; then echo "ERR: NOSTORAGE"; return 3; fi
  chosen=""
  while IFS=$'\t' read -r t path; do
    [ -n "$path" ] || continue
    base="$(basename "$path" | tr 'A-Z' 'a-z')"
    if [ -n "$hint" ]; then case "$base" in *"$hint"*) ;; *) continue ;; esac; fi
    if is_project_src "$path"; then chosen="$path"; break; fi
  done < <(dl_candidates)
  if [ -z "$chosen" ]; then echo "ERR: NOTFOUND"; do_finddl; return 4; fi

  b="$(basename "$chosen")"; b="${b%.zip}"; b="${b%.ZIP}"
  s="$(printf '%s' "$b" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9' | cut -c1-22)"
  [ -n "$s" ] || s="app$(date +%s | tail -c 6)"
  case "$s" in [0-9]*) s="a$s" ;; esac
  if [ -d "$APPS/$s" ] && [ ! -f "$APPS/$s/.yasmin-imported" ]; then s="${s}dl"; fi
  P="$APPS/$s"; T="$P.tmp"
  rm -rf "$T"; mkdir -p "$T"
  if [ -d "$chosen" ]; then
    cp -r "$chosen"/. "$T"/ 2>/dev/null || { echo "ERR: COPYFAILED"; rm -rf "$T"; return 5; }
  else
    unzip -q -o "$chosen" -d "$T" -x '__MACOSX/*' >/dev/null 2>&1 || { echo "ERR: UNZIPFAILED"; rm -rf "$T"; return 5; }
  fi
  sf="$(find "$T" -maxdepth 4 -type f \( -name settings.gradle -o -name settings.gradle.kts \) -not -path '*/__MACOSX/*' 2>/dev/null | awk '{print length($0) "\t" $0}' | sort -n | head -n 1 | cut -f2-)"
  if [ -z "$sf" ]; then echo "ERR: NOPROJECT"; rm -rf "$T"; return 6; fi
  root="$(dirname "$sf")"
  rm -rf "$P"
  mv "$root" "$P" || { echo "ERR: MOVEFAILED"; rm -rf "$T"; return 5; }
  rm -rf "$T"
  rm -rf "$P/build" "$P/.gradle" "$P/app/build" "$P/local.properties"
  gv="$(sed -n 's/.*gradle-\([0-9][0-9.]*\)-\(bin\|all\)\.zip.*/\1/p' "$P/gradle/wrapper/gradle-wrapper.properties" 2>/dev/null | head -n 1)"
  [ -n "$gv" ] || gv="8.9"
  echo "$gv" > "$P/.yasmin-gradle"
  echo "$chosen" > "$P/.yasmin-source"
  touch "$P/.yasmin-imported"
  rm -f "$P/.yasmin-status" "$P/.yasmin-errors"
  echo "SLUG=$s"; echo "NAME=$b"; echo "SRC=$chosen"; echo "GRADLE=$gv"
}

do_build() {
  P="$APPS/$slug"; ST="$P/.yasmin-status"; LOG="$P/build.log"
  [ -d "$P" ] || { echo "no such project"; exit 2; }
  if [ ! -f "$TOOLS/.ready" ]; then
    echo "The build tools are not installed yet." > "$P/.yasmin-errors"; echo FAILED > "$ST"; exit 3
  fi
  echo RUNNING > "$ST"; : > "$LOG"; rm -f "$P/.yasmin-errors"
  wakelock
  cd "$P" || exit 2
  echo "sdk.dir=$ANDROID_HOME" > local.properties
  HEAP="${YASMIN_HEAP:-1536m}"
  GV="$(cat "$P/.yasmin-gradle" 2>/dev/null)"; [ -n "$GV" ] || GV="8.9"
  GH="$(gradle_for "$GV" 2>>"$LOG")"
  [ -x "$GH/bin/gradle" ] || GH="$GRADLE_HOME"
  "$GH/bin/gradle" assembleDebug --no-daemon --console=plain \
    -Pandroid.aapt2FromMavenOverride="$PREFIX/bin/aapt2" \
    -Pkotlin.compiler.execution.strategy=in-process \
    -Dorg.gradle.jvmargs="-Xmx$HEAP -Dfile.encoding=UTF-8" >> "$LOG" 2>&1
  rc=$?
  wakeunlock
  APK="$(find "$P" -path '*/build/outputs/apk/debug/*.apk' -type f 2>/dev/null | head -n 1)"
  if [ $rc -eq 0 ] && [ -n "$APK" ] && [ -f "$APK" ]; then
    cp "$APK" "$P/$slug.apk"
    OUT="$P/$slug.apk"
    if [ -d /sdcard/Download ] && [ -w /sdcard/Download ]; then
      cp "$APK" "/sdcard/Download/YASMIN-AI-$slug.apk" && OUT="/sdcard/Download/YASMIN-AI-$slug.apk"
    fi
    echo "$OUT" > "$P/.yasmin-apk"
    echo OK > "$ST"
  else
    grep -E '^e: |error:|What went wrong|Execution failed|Could not |AAPT|Killed|OutOfMemory|No space' -A2 "$LOG" | head -60 > "$P/.yasmin-errors"
    [ -s "$P/.yasmin-errors" ] || tail -n 30 "$LOG" > "$P/.yasmin-errors"
    echo FAILED > "$ST"
  fi
}

do_status() {
  P="$APPS/$slug"
  if [ -f "$P/.yasmin-status" ]; then head -n 1 "$P/.yasmin-status"; else echo NONE; fi
  [ -f "$P/build.log" ] && tail -n 1 "$P/build.log"
  return 0
}

do_list() {
  cd "$APPS" 2>/dev/null || exit 0
  for d in */; do
    d="${d%/}"
    [ -d "$d" ] || continue
    echo "$d $(head -n 1 "$d/.yasmin-status" 2>/dev/null || echo NEW)"
  done
}

do_dump() {
  cd "$APPS/$slug" 2>/dev/null || exit 2
  find app/src app/build.gradle.kts -type f \( -name '*.kt' -o -name '*.java' -o -name '*.xml' -o -name '*.html' -o -name '*.css' -o -name '*.js' -o -name '*.json' -o -name '*.kts' \) 2>/dev/null | sort | head -40 | while read -r f; do
    echo "=====FILE $f"
    head -c 24000 "$f"
    echo
  done | head -c 90000
}

case "$cmd" in
  setup)  do_setup ;;
  build)  do_build ;;
  status) do_status ;;
  errors) head -c 8000 "$APPS/$slug/.yasmin-errors" 2>/dev/null ;;
  apk)    cat "$APPS/$slug/.yasmin-apk" 2>/dev/null ;;
  list)   do_list ;;
  dump)   do_dump ;;
  fromdl) do_fromdl "${2:-}" ;;
  finddl) do_finddl ;;
  *) echo "usage: build-app.sh setup | build SLUG | status SLUG | errors SLUG | apk SLUG | list | dump SLUG | fromdl [HINT] | finddl"; exit 2 ;;
esac
