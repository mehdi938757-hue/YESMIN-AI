package ai.yasmin.assistant

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.PowerManager
import android.os.SystemClock
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/*
 * v2.48, Phone Unlock: Yasmin locks and unlocks THIS phone by voice.
 *
 * Setup (done by the owner, by hand): switch on the Yasmin accessibility service, switch the feature on, save the phone's own lock
 * (PIN / pattern / password / plain swipe). The secret is encrypted with a non-exportable AES-256-GCM key of the Android Keystore
 * (it has to be readable again to be typed, so it cannot be a hash); if the Keystore is not usable nothing is saved.
 * Unlocking: wake the screen, swipe up, then press the saved PIN on the keypad / type the password / draw the pattern, using the
 * accessibility service (root `input` is used for PIN / password / swipe only when there is no accessibility service).
 * Safety: off until the owner switches it on; refused when Voice Recognition says the speaker is not the owner; after one failed
 * try voice unlock pauses for a minute so the phone's own lockout is never triggered by repeated wrong tries.
 */
object PhoneUnlock {
    private const val ALIAS = "yasmin_phone_unlock_v1"
    private const val K_ON = "pu_enabled"
    private const val K_TYPE = "pu_type"
    private const val K_CIPHER = "pu_cipher"
    private const val PAUSE_MS = 60_000L
    @Volatile private var pausedUntil = 0L
    /** What happened in the last unlock try, step by step (shown on the Phone Unlock page to find out why a phone refuses). */
    @Volatile var lastLog: String = ""

    fun enabled(c: Context): Boolean = Prefs.getBool(c, K_ON, false)
    fun setEnabled(c: Context, v: Boolean) = Prefs.putBool(c, K_ON, v)
    fun type(c: Context): LockType? = LockType.values().firstOrNull { it.name == Prefs.get(c, K_TYPE, "") }
    fun saved(c: Context): Boolean = when (type(c)) { null -> false; LockType.SWIPE -> true; else -> Prefs.get(c, K_CIPHER, "").isNotEmpty() }

    // ------------------------------------------------------------------ saving the phone's lock

    /** null = saved, otherwise what is wrong (in words for the person). */
    fun save(c: Context, t: LockType, secret: String): String? {
        when (t) {
            LockType.PIN -> if (secret.length !in 4..16 || !secret.all { it in '0'..'9' }) return "A PIN is 4 to 16 digits."
            LockType.PATTERN -> if (secret.length < 4 || !secret.all { it in '0'..'8' } || secret.toSet().size != secret.length) return "Draw a pattern of at least 4 dots."
            LockType.PASSWORD -> if (secret.isEmpty() || secret.length > 64) return "Type your phone password (up to 64 characters)."
            LockType.SWIPE -> {}
        }
        if (t == LockType.SWIPE) { Prefs.put(c, K_TYPE, t.name); Prefs.put(c, K_CIPHER, ""); return null }
        val enc = try { encrypt(secret) } catch (_: Throwable) { null }
            ?: return "This phone's secure storage is not available, so the lock was NOT saved."
        Prefs.put(c, K_TYPE, t.name); Prefs.put(c, K_CIPHER, enc)
        return null
    }

    fun clear(c: Context) { Prefs.put(c, K_TYPE, ""); Prefs.put(c, K_CIPHER, ""); setEnabled(c, false) }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return g.generateKey()
    }

    private fun encrypt(plain: String): String {
        val cph = Cipher.getInstance("AES/GCM/NoPadding")
        cph.init(Cipher.ENCRYPT_MODE, key())
        val ct = cph.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cph.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
    }

    private fun secret(c: Context): String? = try {
        val p = Prefs.get(c, K_CIPHER, "").split(':')
        if (p.size != 2) null else {
            val cph = Cipher.getInstance("AES/GCM/NoPadding")
            cph.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)))
            String(cph.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), Charsets.UTF_8)
        }
    } catch (_: Throwable) { null }

    // ------------------------------------------------------------------ status for the page

    fun accessibilityOn(c: Context): Boolean = YasminAccessibilityService.inst != null
    fun locked(c: Context): Boolean = c.getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true
    fun phoneHasLock(c: Context): Boolean = c.getSystemService(KeyguardManager::class.java)?.isDeviceSecure == true

    // ------------------------------------------------------------------ the tools

    private fun err(msg: String) = JSONObject().put("ok", false).put("error", msg)

    fun lock(c: Context): JSONObject = PhoneControl.lockScreen(c)

    fun unlock(c: Context): JSONObject {
        val log = StringBuilder()
        val r = try { doUnlock(c, log) } catch (e: Throwable) { log.append("crash: ").append(e.javaClass.simpleName).append(' ').append(e.message).append('\n'); err("Unlock stopped by an error: ${e.message}") }
        lastLog = log.toString()
        return r.put("log", lastLog)
    }

    private fun doUnlock(c: Context, log: StringBuilder): JSONObject {
        fun L(s: String) { log.append(s).append('\n') }
        if (!enabled(c)) return err("Phone unlock is switched off. The owner can switch it on in the menu under Phone Unlock.")
        if (VoiceId.blocksTools(c)) return err("The voice does not match the owner, so the phone stays locked.")
        val now = SystemClock.uptimeMillis()
        if (now < pausedUntil) return err("The last unlock try failed, so unlocking by voice is paused for a minute to avoid a phone lockout. Tell the owner to check the saved lock in the Phone Unlock page.")
        val t = type(c) ?: return err("No phone lock is saved yet. Save it in the menu under Phone Unlock.")
        val km = c.getSystemService(KeyguardManager::class.java)
        val pm = c.getSystemService(PowerManager::class.java)
        if (pm.isInteractive && !km.isKeyguardLocked) return JSONObject().put("ok", true).put("note", "The phone was already unlocked.")
        val acc = YasminAccessibilityService.inst
        val root = Root.available()
        L("type=${t.name} accessibility=${acc != null} root=$root screenOn=${pm.isInteractive} locked=${km.isKeyguardLocked}")
        if (acc == null && !(root && t != LockType.PATTERN))
            return err(PhoneControl.accProblem(c) ?: "The accessibility service is not connected.")
        val sec = if (t == LockType.SWIPE) "" else secret(c) ?: return err("The saved lock could not be read. Save it again in the Phone Unlock page.")

        acc?.let { it.automationUntil = maxOf(it.automationUntil, SystemClock.uptimeMillis() + 30_000L) }   // the app lock must not cover the phone's lock screen now
        wake(c, pm, root)
        L("after wake: screenOn=${pm.isInteractive}")
        val dm = c.resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        // open the real PIN / pattern / password screen (not the lock-screen news feed)
        if (t != LockType.SWIPE) {
            val shown = openBouncer(c, acc, root, t, w, h, log)
            L("credential screen shown=$shown")
            if (!shown && acc != null) log.append("The credential screen never appeared. What the service sees:\n").append(dump(acc))
        } else openBouncer(c, acc, root, t, w, h, log)

        val typed = when (t) {
            LockType.SWIPE -> true
            LockType.PIN -> if (acc != null) pressPin(acc, sec, log) || rootText(root, sec, true) else rootText(root, sec, true)
            LockType.PASSWORD -> if (acc != null) typePassword(acc, sec, log) || rootText(root, sec, true) else rootText(root, sec, true)
            LockType.PATTERN -> acc != null && drawPattern(acc, sec, log)
        }
        L("entered=$typed")
        val end = SystemClock.uptimeMillis() + 3500
        while (SystemClock.uptimeMillis() < end && km.isKeyguardLocked) sleep(150)
        L("locked after=${km.isKeyguardLocked}")
        UnlockHelperActivity.close()
        return if (!km.isKeyguardLocked) JSONObject().put("ok", true).put("note", "The phone is unlocked now.")
        else {
            pausedUntil = SystemClock.uptimeMillis() + PAUSE_MS
            err(if (typed) "The lock screen did not accept the saved lock. It may have changed: the owner should save it again in the Phone Unlock page."
                else "The lock screen could not be operated (keypad or pattern not found). See the log on the Phone Unlock page.")
        }
    }

    /**
     * Brings up the phone's own credential screen. Tries, in order: (1) KeyguardManager.requestDismissKeyguard through a see-through
     * activity, (2) short fast swipes from the middle of the screen (a swipe from the bottom scrolls a lock-screen news feed instead),
     * (3) a swipe from the lower third. Returns true when the PIN pad / pattern / password field is visible (swipe lock: when the phone opened).
     */
    private fun openBouncer(c: Context, acc: YasminAccessibilityService?, root: Boolean, t: LockType, w: Float, h: Float, log: StringBuilder): Boolean {
        val km = c.getSystemService(KeyguardManager::class.java)
        fun ready(): Boolean = if (t == LockType.SWIPE) !km.isKeyguardLocked else acc != null && hasCredentialUi(acc, t)
        fun waitReady(ms: Long): Boolean { val end = SystemClock.uptimeMillis() + ms; while (SystemClock.uptimeMillis() < end) { if (ready()) return true; sleep(150) }; return ready() }
        if (ready()) return true
        try {
            c.startActivity(Intent(c, UnlockHelperActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
            log.append("asked Android to show the lock screen\n")
        } catch (e: Throwable) { log.append("helper screen failed: ${e.message}\n") }
        if (waitReady(2500)) { log.append("lock screen shown by Android\n"); return true }
        val tries = listOf(floatArrayOf(0.70f, 0.20f, 160f), floatArrayOf(0.55f, 0.12f, 140f), floatArrayOf(0.85f, 0.30f, 220f))
        for ((i, p) in tries.withIndex()) {
            val sw = if (acc != null) acc.swipe(w / 2, h * p[0], w / 2, h * p[1], p[2].toLong())
            else { Root.exec("input swipe ${(w / 2).toInt()} ${(h * p[0]).toInt()} ${(w / 2).toInt()} ${(h * p[1]).toInt()} ${p[2].toInt()}", 4000); true }
            log.append("swipe #${i + 1} (${(p[0] * 100).toInt()}% to ${(p[1] * 100).toInt()}%): $sw\n")
            if (waitReady(1500)) return true
        }
        return false
    }

    @Suppress("DEPRECATION")
    private fun wake(c: Context, pm: PowerManager, root: Boolean) {
        if (pm.isInteractive) return
        if (root) Root.exec("input keyevent 224", 3000)
        else try {
            pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "yasmin:unlock").acquire(4000)
        } catch (_: Throwable) {}
        val end = SystemClock.uptimeMillis() + 2500
        while (SystemClock.uptimeMillis() < end && !pm.isInteractive) sleep(100)
        sleep(600)
    }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }

    private fun rootText(root: Boolean, text: String, enter: Boolean): Boolean {
        if (!root) return false
        Root.exec("input text '" + text.replace("'", "") + "'", 4000)
        if (enter) Root.exec("input keyevent 66", 3000)
        return true
    }

    private fun walk(n: AccessibilityNodeInfo, f: (AccessibilityNodeInfo) -> Boolean): Boolean {
        if (f(n)) return true
        for (i in 0 until n.childCount) { val ch = n.getChild(i) ?: continue; if (walk(ch, f)) return true }
        return false
    }

    private fun label(n: AccessibilityNodeInfo) = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()

    /** A short list of what the accessibility service can see on the lock screen (class | id | text | bounds), for the log. */
    private fun dump(acc: YasminAccessibilityService, max: Int = 30): String {
        val sb = StringBuilder()
        var n = 0
        val roots = acc.allRoots()
        sb.append("windows=").append(roots.size).append('\n')
        for (r in roots) walk(r) { x ->
            if (n < max) {
                val b = Rect(); x.getBoundsInScreen(b)
                sb.append(x.className?.toString()?.substringAfterLast('.')).append(" | ").append(x.viewIdResourceName?.substringAfterLast('/'))
                    .append(" | ").append(label(x).take(20)).append(" | ").append(b.flattenToString()).append('\n')
                n++
            }
            false
        }
        return sb.toString()
    }

    private fun hasCredentialUi(acc: YasminAccessibilityService, t: LockType): Boolean {
        for (r in acc.allRoots()) {
            var hit = false
            walk(r) { n ->
                val id = n.viewIdResourceName.orEmpty(); val cls = n.className?.toString().orEmpty()
                if (t == LockType.PATTERN && (id.contains("pattern", true) || cls.contains("Pattern", true))) hit = true
                if (t == LockType.PIN && label(n) == "5") hit = true
                if (t == LockType.PASSWORD && n.isEditable) hit = true
                hit
            }
            if (hit) return true
        }
        return false
    }

    /** Taps one keypad button (a node whose text or description is exactly [what]); gesture tap on its centre, node click as second try. */
    private fun tapKey(acc: YasminAccessibilityService, what: String): Boolean {
        for (r in acc.allRoots()) {
            var done = false
            walk(r) { n ->
                if (label(n).equals(what, true)) {
                    val b = Rect(); n.getBoundsInScreen(b)
                    done = if (b.width() > 0 && b.height() > 0) acc.tap(b.exactCenterX(), b.exactCenterY()) else false
                    if (!done) done = acc.clickNode(n)
                    true
                } else false
            }
            if (done) return true
        }
        return false
    }

    private fun pressPin(acc: YasminAccessibilityService, pin: String, log: StringBuilder): Boolean {
        for ((i, ch) in pin.withIndex()) {
            if (!tapKey(acc, ch.toString())) { log.append("PIN key #${i + 1} not found\n").append(dump(acc)); return false }
            sleep(140)
        }
        sleep(300)
        if (stillLocked(acc)) { for (e in listOf("Enter", "OK", "Done")) if (tapKey(acc, e)) { log.append("tapped $e\n"); break } }
        return true
    }

    private fun stillLocked(acc: YasminAccessibilityService) = acc.getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true

    private fun typePassword(acc: YasminAccessibilityService, pw: String, log: StringBuilder): Boolean {
        for (r in acc.allRoots()) {
            val f = acc.findEditable(r) ?: continue
            if (!acc.setNodeText(f, pw)) continue
            sleep(250)
            if (!acc.pressEnter()) for (e in listOf("Enter", "OK", "Done")) if (tapKey(acc, e)) break
            return true
        }
        log.append("no password field found\n").append(dump(acc))
        return false
    }

    /** The 3 x 3 pattern grid: the pattern view by id / class (waits up to 3.5 s for it), else the biggest square in the lower screen (estimated). */
    private fun findPatternBox(acc: YasminAccessibilityService, log: StringBuilder): Rect? {
        val dm = acc.resources.displayMetrics
        val sw = dm.widthPixels; val sh = dm.heightPixels
        val end = SystemClock.uptimeMillis() + 3500
        var square: Rect? = null
        while (true) {
            var exact: Rect? = null
            square = null
            for (r in acc.allRoots()) walk(r) { n ->
                val b = Rect(); n.getBoundsInScreen(b)
                val id = n.viewIdResourceName.orEmpty(); val cls = n.className?.toString().orEmpty()
                if (b.width() > 0 && b.height() > 0) {
                    if (exact == null && (id.contains("pattern", true) || cls.contains("Pattern", true))) exact = b
                    else if (square == null && b.width() > sw * 0.5 && b.width() < sw * 1.02 && b.top > sh * 0.3 &&
                        Math.abs(b.width() - b.height()) < b.width() * 0.15) square = b
                }
                false
            }
            val e = exact
            if (e != null) { log.append("pattern view found: ${e.flattenToString()}\n"); return e }
            if (SystemClock.uptimeMillis() > end) break
            sleep(250)
        }
        val q = square
        // An estimated square is only trusted on the phone's real credential screen, never on the lock-screen wallpaper / feed.
        val keyguardPlain = acc.allRoots().any { r -> var hit = false; walk(r) { n -> val id = n.viewIdResourceName.orEmpty(); if (id.contains("magazine") || id.contains("notification_panel")) hit = true; hit }; hit }
        if (q != null && !keyguardPlain) { log.append("pattern view NOT found by name; estimated square ${q.flattenToString()}\n").append(dump(acc)); return q }
        log.append("pattern view not found (plain lock screen still showing=$keyguardPlain); NOT drawing\n").append(dump(acc))
        return null
    }

    /** Draws the pattern with ONE finger through the 3 x 3 dots of the pattern view. */
    private fun drawPattern(acc: YasminAccessibilityService, dots: String, log: StringBuilder): Boolean {
        val b = findPatternBox(acc, log) ?: return false
        val pts = dots.map { ch ->
            val i = ch - '0'
            Pair(b.left + b.width() * ((i % 3) + 0.5f) / 3f, b.top + b.height() * ((i / 3) + 0.5f) / 3f)
        }
        var ok = acc.swipePath(pts, 300L + 320L * pts.size)
        log.append("pattern gesture sent: $ok\n")
        if (!ok) { sleep(500); ok = acc.swipePath(pts, 300L + 320L * pts.size); log.append("pattern gesture retry: $ok\n") }   // cancelled before it finished: one retry
        return ok
    }
}
