# License key setup (v2.49, Firebase Realtime Database)

## 1. Files
- Put `google-services.json` (Firebase console > Project settings > Your apps > Android `ai.yasmin.assistant`) into the **`app/`** folder (next to `app/build.gradle.kts`).
  Download it AFTER you created the Realtime Database, so it contains `firebase_url`.
- The project already has the Google-services plugin line in `build.gradle.kts` and the Firebase dependencies in `app/build.gradle.kts`.
  If Gradle cannot find plugin 4.5.0, change that version to 4.4.4 in the root `build.gradle.kts`.

## 2. Rules
Firebase console > Realtime Database > Rules: paste the content of `firebase-database-rules.json` and Publish.
Effect: nobody can list the keys; a phone can read only the key it types; it can write only its own `deviceId`, only once, only for an active key.

## 3. Add keys (console > Realtime Database > Data)
```
licenses
  YASMIN-7K2Q-9XPD-41AM        <- the key (letters, digits, dashes; 6-64 chars; use long random keys)
      active: true             <- boolean; set false to switch the key off
      expiresAt: 0             <- number; 0 = never, or milliseconds since 1970 (e.g. 1798675200000)
```
Do NOT add `deviceId`: the first phone that activates the key writes it.

## 4. Daily use
- Switch a key off: `active` = false. The phone notices on its next online check (about 12 h; at most 7 days without internet).
- Move a key to another phone: delete that key's `deviceId` in the console.
- On first open the Home screen shows an **Activate license** box at the top: enter the key, press ACTIVATE. The box disappears by itself and the key is then shown in Menu > License.
- **Without a valid key the whole app is locked** (v2.51): no assistant/voice/chat, no background service, no start at boot, no custom lock, no settings pages. If a key is removed or switched off, everything running is stopped at once.

## 5. Honest limit
This stops normal sharing and casual copying. Someone who rebuilds / patches the APK can still remove the check: for stronger protection use a signed server check (Cloud Function) later.
